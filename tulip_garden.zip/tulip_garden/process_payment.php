<?php
session_start();
include 'config.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $booking_id = $_POST['booking_id'];
    $card_holder_name = $_POST['card_holder_name'];
    $card_number = $_POST['card_number'];
    $cvv = $_POST['cvv'];
    $expiry_month = $_POST['expiry_month'];
    $expiry_year = $_POST['expiry_year'];

    // Validate card details (length and format)
    if (strlen($card_number) == 12 && strlen($cvv) == 3 && strlen($expiry_month) == 2 && strlen($expiry_year) == 4) {
        // Check if expiry date is valid
        $current_year = date('Y');
        $current_month = date('m');

        if (($expiry_year > $current_year) || ($expiry_year == $current_year && $expiry_month >= $current_month)) {
            // Get the total amount for the booking
            $stmt = $conn->prepare("
                SELECT rooms.price_per_night, bookings.checkin_date, bookings.checkout_date 
                FROM bookings 
                JOIN rooms ON bookings.room_id = rooms.id 
                WHERE bookings.id = ?
            ");
            $stmt->bind_param("i", $booking_id);
            $stmt->execute();
            $stmt->bind_result($price_per_night, $checkin_date, $checkout_date);
            $stmt->fetch();
            $stmt->close();

            // Calculate the total amount
            $nights = (strtotime($checkout_date) - strtotime($checkin_date)) / (60 * 60 * 24);
            $total_amount = $price_per_night * $nights;

            // Mark the booking as confirmed
            $stmt = $conn->prepare("UPDATE bookings SET status = 'Confirmed' WHERE id = ?");
            $stmt->bind_param("i", $booking_id);
            $stmt->execute();
            $stmt->close();

            // Insert payment record into the payments table
            $stmt = $conn->prepare("INSERT INTO payments (booking_id, card_holder_name, card_number, cvv, expiry_month, expiry_year, amount, payment_date) VALUES (?, ?, ?, ?, ?, ?, ?, NOW())");
            $stmt->bind_param("isssssd", $booking_id, $card_holder_name, $card_number, $cvv, $expiry_month, $expiry_year, $total_amount);
            $stmt->execute();
            $stmt->close();

            // Set success message
            $_SESSION['message'] = 'Payment successful! Your booking is now confirmed.';
            $_SESSION['messageType'] = 'success';
        } else {
            // Set error message for invalid expiry date
            $_SESSION['message'] = 'Invalid expiry date. Please check the expiry month and year.';
            $_SESSION['messageType'] = 'error';
        }
    } else {
        // Set error message for invalid card details
        $_SESSION['message'] = 'Invalid card details. Please check the card number, CVV, and expiry date.';
        $_SESSION['messageType'] = 'error';
    }
}

// Redirect back to mybookings.php to display the alert
header('Location: mybookings.php');
exit;
?>