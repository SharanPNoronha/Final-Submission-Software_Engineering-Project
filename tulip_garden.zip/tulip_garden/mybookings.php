<?php
session_start();
include 'config.php';

// Check if the user is logged in
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

$user_id = $_SESSION['user_id'];

// Retrieve session messages (if any)
$message = '';
$messageType = '';

if (isset($_SESSION['message']) && isset($_SESSION['messageType'])) {
    $message = $_SESSION['message'];
    $messageType = $_SESSION['messageType'];

    // Clear the session message after displaying it
    unset($_SESSION['message']);
    unset($_SESSION['messageType']);
}

// Cancel booking logic
if (isset($_GET['cancel_id'])) {
    $cancel_id = $_GET['cancel_id'];

    // Check if the booking is in the future
    $check_booking_query = "SELECT * FROM bookings WHERE id = ? AND user_id = ? AND checkin_date > CURDATE()";
    $stmt = $conn->prepare($check_booking_query);
    $stmt->bind_param("ii", $cancel_id, $user_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        // Cancel the booking
        $cancel_query = "UPDATE bookings SET status = 'Cancelled' WHERE id = ?";
        $stmt = $conn->prepare($cancel_query);
        $stmt->bind_param("i", $cancel_id);
        if ($stmt->execute()) {
            $message = "Booking cancelled successfully.";
            $messageType = "success";
        } else {
            $message = "Error cancelling booking.";
            $messageType = "error";
        }
    } else {
        $message = "Booking cannot be cancelled as it has already started or is in the past.";
        $messageType = "error";
    }

    $stmt->close();
}

// Fetch user bookings
$bookings_query = "SELECT bookings.*, rooms.type as room_type, rooms.image1, rooms.image2, rooms.image3, rooms.price_per_night 
                   FROM bookings JOIN rooms ON bookings.room_id = rooms.id 
                   WHERE user_id = ? ORDER BY checkin_date DESC";
$stmt = $conn->prepare($bookings_query);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$bookings_result = $stmt->get_result();
$stmt->close();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Bookings - Tulip Garden</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="styles.css">
</head>
<style>
/* General styling */
body {
    background-color: #f7f7f7;
    font-family: 'Poppins', sans-serif;
}

.navbar-brand {
    font-weight: bold;
}

.jumbotron {
    background: linear-gradient(to right, #4e54c8, #8f94fb);
    color: white;
    border-radius: 10px;
    padding: 50px;
    margin-bottom: 30px;
}

/* Search bar styling */
.search-bar {
    margin: 20px 0;
}

/* Luxury table styling */
.table {
    background-color: #ffffff;
    border-radius: 10px;
    box-shadow: 0 8px 15px rgba(0, 0, 0, 0.1);
    margin-top: 20px;
}

.table th,
.table td {
    vertical-align: middle;
    text-align: center;
}

/* Filter buttons */
.filter-btn {
    background-color: #4e54c8;
    color: white;
    margin-left: 10px;
    border-radius: 5px;
}

.filter-btn:hover {
    background-color: #8f94fb;
}

/* Footer styling */
footer {
    background-color: #343a40;
    color: white;
    padding: 20px;
    text-align: center;
    margin-top: 40px;
}
</style>

<body>
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container-fluid">
            <a class="navbar-brand" href="user_home.php">Tulip Garden</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav"
                aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="user_home.php">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="mybookings.php">My Bookings</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="user_rooms.php">Rooms</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="user_payments.php">Payments</a>
                    </li>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="profileDropdown" role="button"
                            data-bs-toggle="dropdown" aria-expanded="false">
                            <i class="fas fa-user"></i>
                        </a>
                        <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="profileDropdown">
                            <li><a class="dropdown-item" href="profile.php"><i class="fas fa-user-edit"></i> Edit
                                    Profile</a></li>
                            <li><a class="dropdown-item" href="logout.php"><i class="fas fa-sign-out-alt"></i>
                                    Logout</a></li>
                        </ul>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <!-- Hero Section -->
    <div class="container mt-5">
        <div class="jumbotron text-center p-5">
            <h1>Your Bookings</h1>
            <p>Keep track of your booking history with us.</p>
        </div>
    </div>

    <div class="container mt-5">
        <!-- Display alert message if exists -->
        <?php if (!empty($message)): ?>
        <div class="alert alert-<?php echo $messageType == 'success' ? 'success' : 'danger'; ?> alert-dismissible fade show"
            role="alert">
            <?php echo $message; ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
        <?php endif; ?>

        <div class="table-responsive">
            <table class="table table-bordered">
                <thead class="table-light">
                    <tr>
                        <th>Booking ID</th>
                        <th>Room Type</th>
                        <th>Check-in Date</th>
                        <th>Check-out Date</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($booking = mysqli_fetch_assoc($bookings_result)) { ?>
                    <tr>
                        <td><?php echo $booking['id']; ?></td>
                        <td><?php echo $booking['room_type']; ?></td>
                        <td><?php echo date("M jS, Y", strtotime($booking['checkin_date'])); ?></td>
                        <td><?php echo date("M jS, Y", strtotime($booking['checkout_date'])); ?></td>
                        <td><?php echo ucfirst($booking['status']); ?></td>
                        <td>
                            <div class="dropdown">
                                <button class="btn btn-secondary dropdown-toggle" type="button"
                                    id="dropdownMenuButton<?php echo $booking['id']; ?>" data-bs-toggle="dropdown"
                                    aria-expanded="false">
                                    <i class="fas fa-ellipsis-v"></i>
                                </button>
                                <ul class="dropdown-menu"
                                    aria-labelledby="dropdownMenuButton<?php echo $booking['id']; ?>">
                                    <li><a class="dropdown-item" href="#" data-bs-toggle="modal"
                                            data-bs-target="#bookingDetailsModal<?php echo $booking['id']; ?>"><i
                                                class="fas fa-eye"></i> View Details</a></li>
                                    <?php if ($booking['status'] == 'Pending') { ?>
                                    <li><a class="dropdown-item" href="#" data-bs-toggle="modal"
                                            data-bs-target="#paymentModal<?php echo $booking['id']; ?>"><i
                                                class="fas fa-credit-card"></i> Pay Now</a></li>
                                    <?php } ?>
                                    <li><a class="dropdown-item" href="?cancel_id=<?php echo $booking['id']; ?>"
                                            onclick="return confirm('Are you sure you want to cancel this booking?');"><i
                                                class="fas fa-times"></i> Cancel</a></li>
                                </ul>
                            </div>
                        </td>
                    </tr>

                    <!-- Booking Details Modal -->
                    <div class="modal fade" id="bookingDetailsModal<?php echo $booking['id']; ?>" tabindex="-1"
                        aria-labelledby="bookingDetailsModalLabel<?php echo $booking['id']; ?>" aria-hidden="true">
                        <div class="modal-dialog modal-lg">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title" id="bookingDetailsModalLabel<?php echo $booking['id']; ?>">
                                        Booking Details</h5>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal"
                                        aria-label="Close"></button>
                                </div>
                                <div class="modal-body">
                                    <div class="row">
                                        <div class="col-md-8">
                                            <div id="carouselExampleIndicators<?php echo $booking['id']; ?>"
                                                class="carousel slide" data-bs-ride="carousel">
                                                <div class="carousel-inner">
                                                    <?php if ($booking['image1']) { ?>
                                                    <div class="carousel-item active">
                                                        <img src="admin/<?php echo $booking['image1']; ?>"
                                                            class="d-block w-100" alt="...">
                                                    </div>
                                                    <?php } ?>
                                                    <?php if ($booking['image2']) { ?>
                                                    <div class="carousel-item">
                                                        <img src="admin/<?php echo $booking['image2']; ?>"
                                                            class="d-block w-100" alt="...">
                                                    </div>
                                                    <?php } ?>
                                                    <?php if ($booking['image3']) { ?>
                                                    <div class="carousel-item">
                                                        <img src="admin/<?php echo $booking['image3']; ?>"
                                                            class="d-block w-100" alt="...">
                                                    </div>
                                                    <?php } ?>
                                                </div>
                                                <button class="carousel-control-prev" type="button"
                                                    data-bs-target="#carouselExampleIndicators<?php echo $booking['id']; ?>"
                                                    data-bs-slide="prev">
                                                    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                                                    <span class="visually-hidden">Previous</span>
                                                </button>
                                                <button class="carousel-control-next" type="button"
                                                    data-bs-target="#carouselExampleIndicators<?php echo $booking['id']; ?>"
                                                    data-bs-slide="next">
                                                    <span class="carousel-control-next-icon" aria-hidden="true"></span>
                                                    <span class="visually-hidden">Next</span>
                                                </button>
                                            </div>
                                        </div>
                                        <div class="col-md-4">
                                            <h5>Booking Information</h5>
                                            <p><strong>Room Type:</strong> <?php echo $booking['room_type']; ?></p>
                                            <p><strong>Check-in Date:</strong>
                                                <?php echo date("M jS, Y", strtotime($booking['checkin_date'])); ?></p>
                                            <p><strong>Check-out Date:</strong>
                                                <?php echo date("M jS, Y", strtotime($booking['checkout_date'])); ?></p>
                                            <p><strong>Price per Night:</strong>
                                                $<?php echo number_format($booking['price_per_night'], 2); ?></p>
                                            <p><strong>Total Price:</strong>
                                                $<?php echo number_format($booking['price_per_night'] * (strtotime($booking['checkout_date']) - strtotime($booking['checkin_date'])) / (60 * 60 * 24), 2); ?>
                                            </p>
                                            <p><strong>Status:</strong> <?php echo ucfirst($booking['status']); ?></p>
                                        </div>
                                    </div>
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary"
                                        data-bs-dismiss="modal">Close</button>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Payment Modal -->
                    <div class="modal fade" id="paymentModal<?php echo $booking['id']; ?>" tabindex="-1"
                        aria-labelledby="paymentModalLabel<?php echo $booking['id']; ?>" aria-hidden="true">
                        <div class="modal-dialog">
                            <div class="modal-content">
                                <form action="process_payment.php" method="POST">
                                    <div class="modal-header">
                                        <h5 class="modal-title" id="paymentModalLabel<?php echo $booking['id']; ?>">
                                            Payment Details</h5>
                                        <button type="button" class="btn-close" data-bs-dismiss="modal"
                                            aria-label="Close"></button>
                                    </div>
                                    <div class="modal-body">
                                        <input type="hidden" name="booking_id" value="<?php echo $booking['id']; ?>">
                                        <div class="mb-3">
                                            <label for="cardHolderName" class="form-label">Card Holder Name</label>
                                            <input type="text" class="form-control" id="cardHolderName"
                                                name="card_holder_name" required>
                                        </div>
                                        <div class="mb-3">
                                            <label for="cardNumber" class="form-label">Card Number</label>
                                            <input type="text" class="form-control" id="cardNumber" name="card_number"
                                                required minlength="12" maxlength="12" pattern="\d{12}"
                                                title="Card number must be 12 digits">
                                        </div>
                                        <div class="mb-3">
                                            <label for="cvv" class="form-label">CVV</label>
                                            <input type="text" class="form-control" id="cvv" name="cvv" required
                                                minlength="3" maxlength="3" pattern="\d{3}"
                                                title="CVV must be 3 digits">
                                        </div>
                                        <div class="mb-3">
                                            <label for="expiryMonth" class="form-label">Expiry Month</label>
                                            <input type="text" class="form-control" id="expiryMonth" name="expiry_month"
                                                required maxlength="2" pattern="\d{2}"
                                                title="Month should be in MM format">
                                        </div>
                                        <div class="mb-3">
                                            <label for="expiryYear" class="form-label">Expiry Year</label>
                                            <input type="text" class="form-control" id="expiryYear" name="expiry_year"
                                                required maxlength="4" pattern="\d{4}"
                                                title="Year should be in YYYY format">
                                        </div>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-secondary"
                                            data-bs-dismiss="modal">Cancel</button>
                                        <button type="submit" class="btn btn-primary">Pay Now</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>

                    <?php } ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- Footer -->
    <footer class="bg-dark text-white text-center p-3 mt-5">
        <p>&copy; <?php echo date("Y"); ?> Tulip Garden. All Rights Reserved.</p>
    </footer>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"></script>

</body>

</html>