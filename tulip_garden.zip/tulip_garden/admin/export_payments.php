<?php
include '../config.php';
session_start();

// Set the content type to CSV
header('Content-Type: text/csv; charset=utf-8');

// Define the file name for the download
header('Content-Disposition: attachment; filename=payments.csv');

// Create a file pointer connected to the output stream
$output = fopen('php://output', 'w');

// Output the column headings for the CSV file
fputcsv($output, array('ID', 'Booking ID', 'Card Holder Name', 'Card Number', 'Amount', 'Payment Date'));

// Fetch payments from the database
$payments_query = "SELECT * FROM payments ORDER BY payment_date DESC";
$payments_result = mysqli_query($conn, $payments_query);

// Loop through the payments and write each row to the CSV
while ($row = mysqli_fetch_assoc($payments_result)) {
    // Mask the card number except for the last 4 digits
    $row['card_number'] = str_repeat('*', 12) . substr($row['card_number'], -4);

    // Output the row as a CSV line
    fputcsv($output, $row);
}

// Close the output stream
fclose($output);

// End script execution
exit();
?>