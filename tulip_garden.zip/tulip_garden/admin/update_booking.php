<?php
include '../config.php';
session_start();

// Check if admin is logged in
if (!isset($_SESSION['admin'])) {
    header('Location: ../login.php');
    exit;
}

// Get booking ID and status from URL
$booking_id = $_GET['id'];
$status = $_GET['status'];

// Update booking status in the database
$update_query = "UPDATE bookings SET status='$status' WHERE id='$booking_id'";
if (mysqli_query($conn, $update_query)) {
    $_SESSION['message'] = "Booking status updated successfully!";
    $_SESSION['messageType'] = 'success';
} else {
    $_SESSION['message'] = "Failed to update booking status!";
    $_SESSION['messageType'] = 'error';
}

// Redirect back to bookings page
header("Location: bookings.php");
exit;
?>