<?php
include '../config.php';
session_start();

// Check if admin is logged in
if (!isset($_SESSION['admin'])) {
    header('Location: ../login.php');
    exit;
}

// Get booking ID from URL
$booking_id = $_GET['id'];

// Delete the booking from the database
$delete_query = "DELETE FROM bookings WHERE id='$booking_id'";
if (mysqli_query($conn, $delete_query)) {
    $_SESSION['message'] = "Booking deleted successfully!";
    $_SESSION['messageType'] = 'success';
} else {
    $_SESSION['message'] = "Failed to delete booking!";
    $_SESSION['messageType'] = 'error';
}

// Redirect back to bookings page
header("Location: bookings.php");
exit;
?>