<?php
include '../config.php';
session_start();

if (isset($_GET['id'])) {
    $payment_id = $_GET['id'];

    // Delete payment from the database
    $delete_query = "DELETE FROM payments WHERE id = ?";
    $stmt = $conn->prepare($delete_query);
    $stmt->bind_param("i", $payment_id);

    if ($stmt->execute()) {
        header("Location: payments.php?msg=deleted");
    } else {
        header("Location: payments.php?msg=error");
    }

    $stmt->close();
}
?>