<?php
include '../config.php';
session_start();

$message = '';
$messageType = '';

// Handle adding a new staff member
if (isset($_POST['submit'])) {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $position = $_POST['position'];
    $salary = $_POST['salary'];

    $stmt = $conn->prepare("INSERT INTO staff (name, email, phone, position, salary) VALUES (?, ?, ?, ?, ?)");
    $stmt->bind_param("ssssd", $name, $email, $phone, $position, $salary);

    if ($stmt->execute()) {
        $message = "Staff member added successfully!";
        $messageType = "success";
    } else {
        $message = "Error adding staff member: " . $stmt->error;
        $messageType = "error";
    }

    $stmt->close();
}

// Handle editing a staff member
if (isset($_POST['edit'])) {
    $staff_id = $_POST['staff_id'];
    $name = $_POST['name'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $position = $_POST['position'];
    $salary = $_POST['salary'];

    $stmt = $conn->prepare("UPDATE staff SET name=?, email=?, phone=?, position=?, salary=? WHERE id=?");
    $stmt->bind_param("ssssdi", $name, $email, $phone, $position, $salary, $staff_id);

    if ($stmt->execute()) {
        $message = "Staff member updated successfully!";
        $messageType = "success";
    } else {
        $message = "Error updating staff member: " . $stmt->error;
        $messageType = "error";
    }

    $stmt->close();
}

// Handle deleting a staff member
if (isset($_GET['delete'])) {
    $staff_id = $_GET['delete'];

    $stmt = $conn->prepare("DELETE FROM staff WHERE id=?");
    $stmt->bind_param("i", $staff_id);

    if ($stmt->execute()) {
        $message = "Staff member deleted successfully!";
        $messageType = "success";
    } else {
        $message = "Error deleting staff member: " . $stmt->error;
        $messageType = "error";
    }

    $stmt->close();
}

// Fetch staff from the database
$staff_query = "SELECT * FROM staff ORDER BY created_at DESC";
$staff_result = mysqli_query($conn, $staff_query);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Staff</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css">
    <!-- Toastr CSS -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">
    <!-- Font Awesome for icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <!-- Custom CSS -->
    <link rel="stylesheet" href="../styles.css">
</head>
<style>
#sidebar {
    display: none;
    position: fixed;
    left: 0;
    top: 60px;
    height: 100%;
    width: 150px;
    background-color: #f8f9fa;
    z-index: 1000;
    overflow-y: auto;
}

#sidebar.active {
    display: block;
}

#sidebar ul {
    padding: 0;
}

#sidebar .nav-item {
    list-style: none;
    margin: 0;
}

#sidebar .nav-link {
    color: #333;
    padding: 10px;
    display: block;
    text-decoration: none;
}

#sidebar .nav-link.active {
    background-color: #007bff;
    color: #fff;
    border-radius: 10px;
}

#sidebar .nav-link:hover {
    background-color: #007bff;
    color: #fff;
}

@media (min-width: 900px) {
    #sidebar {
        display: block;
        position: relative;
        width: 150px;
    }

    #sidebar.active {
        display: block;
    }
}

#toggleButton {
    display: block;
    position: fixed;
    top: 70px;
    right: 20px;
    z-index: 1100;
    background-color: #007bff;
    color: #fff;
    border: none;
    border-radius: 15px;
    padding: 10px;
}

@media (min-width: 900px) {
    #toggleButton {
        display: none;
    }
}
</style>

<body>

    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
        <div class="container-fluid">
            <a class="navbar-brand" href="#">Admin Dashboard</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav"
                aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="../logout.php">Logout</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
    <button id="toggleButton" onclick="toggleSidebar()">
        Menu
    </button>

    <!-- Sidebar and Content -->
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <!-- Sidebar -->
            <nav id="sidebar" class="bg-light">
                <div class="position-sticky pt-3">
                    <ul class="nav flex-column">
                        <li class="nav-item mb-2">
                            <a class="nav-link" href="../admin_dashboard.php">
                                <i class="fas fa-tachometer-alt"></i>
                                Dashboard
                            </a>
                        </li>
                        <li class="nav-item mb-2">
                            <a class="nav-link" href="users.php">
                                <i class="fas fa-users"></i>
                                Users
                            </a>
                        </li>
                        <li class="nav-item mb-2">
                            <a class="nav-link" href="bookings.php">
                                <i class="fas fa-calendar-check"></i>
                                Bookings
                            </a>
                        </li>
                        <li class="nav-item mb-2">
                            <a class="nav-link" href="rooms.php">
                                <i class="fas fa-bed"></i>
                                Rooms
                            </a>
                        </li>
                        <li class="nav-item mb-2">
                            <a class="nav-link" href="payments.php">
                                <i class="fas fa-money-check-alt"></i>
                                Payments
                            </a>
                        </li>
                        <li class="nav-item mb-2">
                            <a class="nav-link active" href="#">
                                <i class="fas fa-users-cog"></i>
                                Staff
                            </a>
                        </li>
                        <li class="nav-item mb-2">
                            <a class="nav-link" href="settings.php">
                                <i class="fas fa-cog"></i>
                                Settings
                            </a>
                        </li>
                    </ul>
                </div>
            </nav>

            <script>
            function toggleSidebar() {
                document.getElementById("sidebar").classList.toggle("active");
            }
            </script>

            <!-- Main Content -->
            <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4" style="margin-top: 80px;">
                <h2 class="mb-4">Manage Staff</h2>

                <button class="btn btn-primary mb-4" data-bs-toggle="modal" data-bs-target="#addStaffModal">
                    <i class="fas fa-plus"></i> Add New Staff
                </button>

                <div class="table-responsive">
                    <table class="table table-bordered">
                        <thead class="table-light">
                            <tr>
                                <th>ID</th>
                                <th>Name</th>
                                <th>Email</th>
                                <th>Phone</th>
                                <th>Position</th>
                                <th>Salary</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while ($staff = mysqli_fetch_assoc($staff_result)) { ?>
                            <tr>
                                <td><?php echo $staff['id']; ?></td>
                                <td><?php echo $staff['name']; ?></td>
                                <td><?php echo $staff['email']; ?></td>
                                <td><?php echo $staff['phone']; ?></td>
                                <td><?php echo $staff['position']; ?></td>
                                <td><?php echo '$' . number_format($staff['salary'], 2); ?></td>
                                <td>
                                    <div class="dropdown">
                                        <button class="btn btn-secondary dropdown-toggle" type="button"
                                            id="dropdownMenuButton<?php echo $staff['id']; ?>" data-bs-toggle="dropdown"
                                            aria-expanded="false">
                                            <i class="fas fa-ellipsis-v"></i>
                                        </button>
                                        <ul class="dropdown-menu"
                                            aria-labelledby="dropdownMenuButton<?php echo $staff['id']; ?>">
                                            <li><a class="dropdown-item" href="#" data-bs-toggle="modal"
                                                    data-bs-target="#editStaffModal<?php echo $staff['id']; ?>">Edit</a>
                                            </li>
                                            <li><a class="dropdown-item" href="?delete=<?php echo $staff['id']; ?>"
                                                    onclick="return confirm('Are you sure you want to delete this staff member?');">Delete</a>
                                            </li>
                                        </ul>
                                    </div>
                                </td>
                            </tr>

                            <!-- Edit Staff Modal -->
                            <div class="modal fade" id="editStaffModal<?php echo $staff['id']; ?>" tabindex="-1"
                                aria-labelledby="editStaffModalLabel" aria-hidden="true">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <form method="POST">
                                            <div class="modal-header">
                                                <h5 class="modal-title" id="editStaffModalLabel">Edit Staff Member</h5>
                                                <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                    aria-label="Close"></button>
                                            </div>
                                            <div class="modal-body">
                                                <input type="hidden" name="staff_id"
                                                    value="<?php echo $staff['id']; ?>">
                                                <div class="mb-3">
                                                    <label for="name" class="form-label">Name</label>
                                                    <input type="text" class="form-control" id="name" name="name"
                                                        value="<?php echo $staff['name']; ?>" required>
                                                </div>
                                                <div class="mb-3">
                                                    <label for="email" class="form-label">Email</label>
                                                    <input type="email" class="form-control" id="email" name="email"
                                                        value="<?php echo $staff['email']; ?>" required>
                                                </div>
                                                <div class="mb-3">
                                                    <label for="phone" class="form-label">Phone</label>
                                                    <input type="text" class="form-control" id="phone" name="phone"
                                                        value="<?php echo $staff['phone']; ?>" required>
                                                </div>
                                                <div class="mb-3">
                                                    <label for="position" class="form-label">Position</label>
                                                    <input type="text" class="form-control" id="position"
                                                        name="position" value="<?php echo $staff['position']; ?>"
                                                        required>
                                                </div>
                                                <div class="mb-3">
                                                    <label for="salary" class="form-label">Salary</label>
                                                    <input type="number" class="form-control" id="salary" name="salary"
                                                        value="<?php echo $staff['salary']; ?>" required>
                                                </div>
                                            </div>
                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-secondary"
                                                    data-bs-dismiss="modal">Close</button>
                                                <button type="submit" name="edit" class="btn btn-primary">Save
                                                    Changes</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                            <?php } ?>
                        </tbody>
                    </table>
                </div>
            </main>
        </div>
    </div>

    <!-- Add Staff Modal -->
    <div class="modal fade" id="addStaffModal" tabindex="-1" aria-labelledby="addStaffModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <form method="POST">
                    <div class="modal-header">
                        <h5 class="modal-title" id="addStaffModalLabel">Add New Staff Member</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <div class="mb-3">
                            <label for="name" class="form-label">Name</label>
                            <input type="text" class="form-control" id="name" name="name" required>
                        </div>
                        <div class="mb-3">
                            <label for="email" class="form-label">Email</label>
                            <input type="email" class="form-control" id="email" name="email" required>
                        </div>
                        <div class="mb-3">
                            <label for="phone" class="form-label">Phone</label>
                            <input type="text" class="form-control" id="phone" name="phone" required>
                        </div>
                        <div class="mb-3">
                            <label for="position" class="form-label">Position</label>
                            <input type="text" class="form-control" id="position" name="position" required>
                        </div>
                        <div class="mb-3">
                            <label for="salary" class="form-label">Salary</label>
                            <input type="number" class="form-control" id="salary" name="salary" required>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                        <button type="submit" name="submit" class="btn btn-primary">Add Staff</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- jQuery -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <!-- Toastr JS -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>
    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"></script>

    <script>
    <?php if ($message): ?>
    toastr.options = {
        "closeButton": true,
        "progressBar": true,
        "positionClass": "toast-top-right",
        "showDuration": "300",
        "hideDuration": "1000",
        "timeOut": "5000",
        "extendedTimeOut": "1000",
        "showEasing": "swing",
        "hideEasing": "linear",
        "showMethod": "fadeIn",
        "hideMethod": "fadeOut"
    };
    toastr.<?php echo $messageType === 'success' ? 'success' : 'error'; ?>('<?php echo $message; ?>');
    <?php endif; ?>
    </script>

</body>

</html>