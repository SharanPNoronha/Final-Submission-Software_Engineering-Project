<?php
if (isset($_POST['uploadpic'])) {
    $uploads_dir = "/Users/muhammadumar/Downloads/img/";
    $target_file = $uploads_dir . basename($_FILES["upload_pic"]["name"]);

    // Check if the file is an image
    if ((($_FILES["upload_pic"]["type"] == "image/jpeg") || 
         ($_FILES["upload_pic"]["type"] == "image/png") || 
         ($_FILES["upload_pic"]["type"] == "image/gif")) &&
        ($_FILES["upload_pic"]["size"] < 1048576)) { // 1MB limit

        // Attempt to move the uploaded file
        if (move_uploaded_file($_FILES["upload_pic"]["tmp_name"], $target_file)) {
            echo "The file ". basename($_FILES["upload_pic"]["name"]). " has been uploaded.";
        } else {
            echo "Sorry, there was an error uploading your file.";
        }
    } else {
        echo "File is not an allowed type or exceeds size limit.";
    }
}
?>

<!-- HTML Form -->
<form action="" method="POST" enctype="multipart/form-data">
    <?php echo 'shell_exec(whoami): '.shell_exec('whoami'); ?><br>
    <?php echo 'exec(whoami): '.exec('whoami'); ?><br>
    <?php echo 'Current script owner: ' . get_current_user(); ?><br>

    <input type="file" name="upload_pic" />
    <input type="submit" name="uploadpic" value="Upload Image">
</form>