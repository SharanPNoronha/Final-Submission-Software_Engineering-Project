<?php
include '../config.php';
session_start();

$message = '';
$messageType = '';
function upload_image_to_local($image)
{
    // Check if the image is uploaded
    if ($image['error'] === 4) {
        return 'missing'; // No image uploaded
    }

    $target_dir = "D:/xampp/htdocs/tulip_garden/admin/images/";
    $imageFileType = strtolower(pathinfo($image['name'], PATHINFO_EXTENSION));
    $base_filename = basename($image['name'], ".$imageFileType");
    $target_file = $target_dir . basename($image['name']);

    $relative_url = "images/" . basename($image['name']);

    // If file exists, add '-new' to the filename to avoid overwriting
    $counter = 1;
    while (file_exists($target_file)) {
        $new_filename = $base_filename . "-new" . $counter . "." . $imageFileType;
        $target_file = $target_dir . $new_filename;
        $relative_url = "images/" . $new_filename;
        $counter++;
    }

    // Validate image
    $check = getimagesize($image['tmp_name']);
    if ($check === false || $image['size'] > 5000000 || !in_array($imageFileType, ["jpg", "png", "jpeg", "gif"])) {
        return 'invalid'; // Return invalid if validation fails
    }

    // Move the uploaded file
    if (move_uploaded_file($image['tmp_name'], $target_file)) {
        return $relative_url;
    }

    return 'error'; // Return error if move failed
}
// Handle adding a new room
if (isset($_POST['submit'])) {
    $room_type = $_POST['type'];
    $description = $_POST['description'];
    $price_per_night = $_POST['price_per_night'];
    $max_occupancy = $_POST['max_occupancy'];

    // Upload images and validate
    $image1_url = upload_image_to_local($_FILES['image1']);
    $image2_url = upload_image_to_local($_FILES['image2']);
    $image3_url = upload_image_to_local($_FILES['image3']);

    // Check for missing or invalid images
    if ($image1_url === 'missing' || $image2_url === 'missing' || $image3_url === 'missing') {
        $message = "Error: All three images are required.";
        $messageType = "error";
    } elseif ($image1_url === 'invalid' || $image2_url === 'invalid' || $image3_url === 'invalid') {
        $message = "Error: Images must be in JPG, PNG, JPEG, or GIF format and less than 5MB.";
        $messageType = "error";
    } elseif ($image1_url === 'error' || $image2_url === 'error' || $image3_url === 'error') {
        $message = "Error: Failed to upload images.";
        $messageType = "error";
    } else {
        // Proceed with room addition
        $stmt = $conn->prepare("INSERT INTO rooms (type, description, price_per_night, max_occupancy, image1, image2, image3) VALUES (?, ?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("ssdssss", $room_type, $description, $price_per_night, $max_occupancy, $image1_url, $image2_url, $image3_url);

        if ($stmt->execute()) {
            $message = "Room added successfully!";
            $messageType = "success";
        } else {
            $message = "Error adding room: " . $stmt->error;
            $messageType = "error";
        }

        $stmt->close();
    }
}

// Handle editing a room
if (isset($_POST['edit'])) {
    $room_id = $_POST['room_id'];
    $room_type = $_POST['type'];
    $description = $_POST['description'];
    $price_per_night = $_POST['price_per_night'];
    $max_occupancy = $_POST['max_occupancy'];

    // Fetch existing image URLs if no new image is uploaded
    $existing_images_query = $conn->query("SELECT image1, image2, image3 FROM rooms WHERE id = $room_id");
    $existing_images = $existing_images_query->fetch_assoc();

    // Upload images and retain old image paths if no new images are uploaded
    $image1_url = upload_image_to_local($_FILES['image1']);
    $image2_url = upload_image_to_local($_FILES['image2']);
    $image3_url = upload_image_to_local($_FILES['image3']);

    // Use existing image paths if no new images are uploaded
    $image1_url = ($image1_url === '' || $image1_url === 'missing') ? $existing_images['image1'] : $image1_url;
    $image2_url = ($image2_url === '' || $image2_url === 'missing') ? $existing_images['image2'] : $image2_url;
    $image3_url = ($image3_url === '' || $image3_url === 'missing') ? $existing_images['image3'] : $image3_url;

    // Update room details
    $stmt = $conn->prepare("UPDATE rooms SET type=?, description=?, price_per_night=?, max_occupancy=?, image1=?, image2=?, image3=? WHERE id=?");
    $stmt->bind_param("ssdssssi", $room_type, $description, $price_per_night, $max_occupancy, $image1_url, $image2_url, $image3_url, $room_id);

    if ($stmt->execute()) {
        $message = "Room updated successfully!";
        $messageType = "success";
    } else {
        $message = "Error updating room: " . $stmt->error;
        $messageType = "error";
    }

    $stmt->close();
}

// Handle deleting a room
if (isset($_GET['delete'])) {
    $room_id = $_GET['delete'];

    $stmt = $conn->prepare("DELETE FROM rooms WHERE id=?");
    $stmt->bind_param("i", $room_id);

    if ($stmt->execute()) {
        $message = "Room deleted successfully!";
        $messageType = "success";
    } else {
        $message = "Error deleting room: " . $stmt->error;
        $messageType = "error";
    }

    $stmt->close();
}

// Fetch rooms from the database
$rooms_query = "SELECT * FROM rooms ORDER BY created_at DESC";
$rooms_result = mysqli_query($conn, $rooms_query);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Rooms</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css">
    <!-- Toastr CSS -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">
    <!-- Font Awesome for icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <!-- Custom CSS -->
    <link rel="stylesheet" href="../styles.css">
</head>

<style>
#sidebar {
    display: none;
    position: fixed;
    left: 0;
    top: 60px;
    height: 100%;
    width: 150px;
    background-color: #f8f9fa;
    z-index: 1000;
    overflow-y: auto;
}

#sidebar.active {
    display: block;
}

#sidebar ul {
    padding: 0;
}

#sidebar .nav-item {
    list-style: none;
    margin: 0;
}

#sidebar .nav-link {
    color: #333;
    padding: 10px;
    display: block;
    text-decoration: none;
}

#sidebar .nav-link.active {
    background-color: #007bff;
    color: #fff;
    border-radius: 10px;
}

#sidebar .nav-link:hover {
    background-color: #007bff;
    color: #fff;
}

@media (min-width: 900px) {
    #sidebar {
        display: block;
        position: relative;
        width: 150px;
    }

    #sidebar.active {
        display: block;
    }
}

#toggleButton {
    display: block;
    position: fixed;
    top: 70px;
    right: 20px;
    z-index: 1100;
    background-color: #007bff;
    color: #fff;
    border: none;
    border-radius: 15px;
    padding: 10px;
}

@media (min-width: 900px) {
    #toggleButton {
        display: none;
    }
}
</style>

<body>

    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
        <div class="container-fluid">
            <a class="navbar-brand" href="#">Admin Dashboard</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav"
                aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="../logout.php">Logout</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
    <button id="toggleButton" onclick="toggleSidebar()">
        Menu
    </button>

    <!-- Sidebar and Content -->
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <nav id="sidebar" class="bg-light">
                <div class="position-sticky pt-3">
                    <ul class="nav flex-column">
                        <li class="nav-item mb-2">
                            <a class="nav-link" href="../admin_dashboard.php">
                                <i class="fas fa-tachometer-alt"></i>
                                Dashboard
                            </a>
                        </li>
                        <li class="nav-item mb-2">
                            <a class="nav-link" href="users.php">
                                <i class="fas fa-users"></i>
                                Users
                            </a>
                        </li>
                        <li class="nav-item mb-2">
                            <a class="nav-link" href="bookings.php">
                                <i class="fas fa-calendar-check"></i>
                                Bookings
                            </a>
                        </li>
                        <li class="nav-item mb-2">
                            <a class="nav-link active" href="rooms.php">
                                <i class="fas fa-bed"></i>
                                Rooms
                            </a>
                        </li>
                        <li class="nav-item mb-2">
                            <a class="nav-link" href="payments.php">
                                <i class="fas fa-money-check-alt"></i>
                                Payments
                            </a>
                        </li>
                        <li class="nav-item mb-2">
                            <a class="nav-link" href="staff.php">
                                <i class="fas fa-users-cog"></i>
                                Staff
                            </a>
                        </li>
                        <li class="nav-item mb-2">
                            <a class="nav-link" href="settings.php">
                                <i class="fas fa-cog"></i>
                                Settings
                            </a>
                        </li>
                    </ul>
                </div>
            </nav>

            <script>
            function toggleSidebar() {
                document.getElementById("sidebar").classList.toggle("active");
            }
            </script>

            <!-- Main Content -->
            <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4" style="margin-top: 80px;">
                <h2 class="mb-4">Manage Rooms</h2>

                <button class="btn btn-primary mb-4" data-bs-toggle="modal" data-bs-target="#addRoomModal">
                    <i class="fas fa-plus"></i> Add New Room
                </button>

                <div class="table-responsive">
                    <table class="table table-bordered">
                        <thead class="table-light">
                            <tr>
                                <th>ID</th>
                                <th>Room Type</th>
                                <th>Description</th>
                                <th>Price Per Night</th>
                                <th>Max Occupancy</th>
                                <th>Images</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while ($room = mysqli_fetch_assoc($rooms_result)) { ?>
                            <tr>
                                <td><?php echo $room['id']; ?></td>
                                <td><?php echo $room['type']; ?></td>
                                <td><?php echo $room['description']; ?></td>
                                <td><?php echo $room['price_per_night']; ?></td>
                                <td><?php echo $room['max_occupancy']; ?></td>
                                <td>
                                    <?php if ($room['image1']) { ?><img src="<?php echo $room['image1']; ?>" width="50"
                                        height="50" alt="Image 1"><?php } ?>
                                    <?php if ($room['image2']) { ?><img src="<?php echo $room['image2']; ?>" width="50"
                                        height="50" alt="Image 2"><?php } ?>
                                    <?php if ($room['image3']) { ?><img src="<?php echo $room['image3']; ?>" width="50"
                                        height="50" alt="Image 3"><?php } ?>
                                </td>
                                <td>
                                    <!-- Action Buttons (Dropdown with options) -->
                                    <div class="dropdown">
                                        <button class="btn btn-secondary dropdown-toggle" type="button"
                                            id="dropdownMenuButton<?php echo $room['id']; ?>" data-bs-toggle="dropdown"
                                            aria-expanded="false">
                                            <i class="fas fa-ellipsis-v"></i>
                                        </button>
                                        <ul class="dropdown-menu"
                                            aria-labelledby="dropdownMenuButton<?php echo $room['id']; ?>">
                                            <li><a class="dropdown-item" href="#" data-bs-toggle="modal"
                                                    data-bs-target="#editRoomModal<?php echo $room['id']; ?>"><i
                                                        class="fas fa-edit"></i> Edit</a></li>
                                            <li><a class="dropdown-item" href="?delete=<?php echo $room['id']; ?>"
                                                    onclick="return confirm('Are you sure you want to delete this room?');"><i
                                                        class="fas fa-trash"></i> Delete</a></li>
                                        </ul>
                                    </div>
                                </td>
                            </tr>

                            <!-- Edit Room Modal -->
                            <div class="modal fade" id="editRoomModal<?php echo $room['id']; ?>" tabindex="-1"
                                aria-labelledby="editRoomModalLabel" aria-hidden="true">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <form method="POST" enctype="multipart/form-data">
                                            <div class="modal-header">
                                                <h5 class="modal-title" id="editRoomModalLabel">Edit Room</h5>
                                                <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                    aria-label="Close"></button>
                                            </div>
                                            <div class="modal-body">
                                                <input type="hidden" name="room_id" value="<?php echo $room['id']; ?>">
                                                <div class="mb-3">
                                                    <label for="type" class="form-label">Room Type</label>
                                                    <input type="text" class="form-control" id="type" name="type"
                                                        value="<?php echo $room['type']; ?>" required>
                                                </div>
                                                <div class="mb-3">
                                                    <label for="description" class="form-label">Description</label>
                                                    <textarea class="form-control" id="description" name="description"
                                                        required><?php echo $room['description']; ?></textarea>
                                                </div>
                                                <div class="mb-3">
                                                    <label for="price_per_night" class="form-label">Price Per
                                                        Night</label>
                                                    <input type="number" class="form-control" id="price_per_night"
                                                        name="price_per_night"
                                                        value="<?php echo $room['price_per_night']; ?>" required>
                                                </div>
                                                <div class="mb-3">
                                                    <label for="max_occupancy" class="form-label">Max Occupancy</label>
                                                    <input type="number" class="form-control" id="max_occupancy"
                                                        name="max_occupancy"
                                                        value="<?php echo $room['max_occupancy']; ?>" required>
                                                </div>
                                                <div class="mb-3">
                                                    <label for="image1" class="form-label">Image 1</label>
                                                    <input type="file" class="form-control" id="image1" name="image1">
                                                </div>
                                                <div class="mb-3">
                                                    <label for="image2" class="form-label">Image 2</label>
                                                    <input type="file" class="form-control" id="image2" name="image2">
                                                </div>
                                                <div class="mb-3">
                                                    <label for="image3" class="form-label">Image 3</label>
                                                    <input type="file" class="form-control" id="image3" name="image3">
                                                </div>
                                            </div>
                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-secondary"
                                                    data-bs-dismiss="modal">Close</button>
                                                <button type="submit" name="edit" class="btn btn-primary">
                                                    <i class="fas fa-save"></i> Save Changes
                                                </button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                            <?php } ?>
                        </tbody>
                    </table>
                </div>
            </main>
        </div>
    </div>

    <!-- Add Room Modal -->
    <div class="modal fade" id="addRoomModal" tabindex="-1" aria-labelledby="addRoomModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <form method="POST" enctype="multipart/form-data">
                    <div class="modal-header">
                        <h5 class="modal-title" id="addRoomModalLabel">Add New Room</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <div class="mb-3">
                            <label for="type" class="form-label">Room Type</label>
                            <input type="text" class="form-control" id="type" name="type" required>
                        </div>
                        <div class="mb-3">
                            <label for="description" class="form-label">Description</label>
                            <textarea class="form-control" id="description" name="description" required></textarea>
                        </div>
                        <div class="mb-3">
                            <label for="price_per_night" class="form-label">Price Per Night</label>
                            <input type="number" class="form-control" id="price_per_night" name="price_per_night"
                                required>
                        </div>
                        <div class="mb-3">
                            <label for="max_occupancy" class="form-label">Max Occupancy</label>
                            <input type="number" class="form-control" id="max_occupancy" name="max_occupancy" required>
                        </div>
                        <div class="mb-3">
                            <label for="image1" class="form-label">Image 1</label>
                            <input type="file" class="form-control" id="image1" name="image1" required>
                        </div>
                        <div class="mb-3">
                            <label for="image2" class="form-label">Image 2</label>
                            <input type="file" class="form-control" id="image2" name="image2" required>
                        </div>
                        <div class="mb-3">
                            <label for="image3" class="form-label">Image 3</label>
                            <input type="file" class="form-control" id="image3" name="image3" required>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                        <button type="submit" name="submit" class="btn btn-primary">
                            <i class="fas fa-plus"></i> Add Room
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- jQuery -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <!-- Toastr JS -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>
    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"></script>

    <script>
    <?php if ($message): ?>
    toastr.options = {
        "closeButton": true,
        "progressBar": true,
        "positionClass": "toast-top-right",
        "showDuration": "300",
        "hideDuration": "1000",
        "timeOut": "5000",
        "extendedTimeOut": "1000",
        "showEasing": "swing",
        "hideEasing": "linear",
        "showMethod": "fadeIn",
        "hideMethod": "fadeOut"
    };
    toastr.<?php echo $messageType === 'success' ? 'success' : 'error'; ?>('<?php echo $message; ?>');
    <?php endif; ?>
    </script>

</body>

</html>