<?php
include '../config.php';
session_start();

$message = '';
$messageType = '';

if (isset($_GET['msg'])) {
    if ($_GET['msg'] == 'updated') {
        $message = 'Payment updated successfully!';
        $messageType = 'success';
    } elseif ($_GET['msg'] == 'deleted') {
        $message = 'Payment deleted successfully!';
        $messageType = 'success';
    } elseif ($_GET['msg'] == 'error') {
        $message = 'An error occurred!';
        $messageType = 'error';
    }
}

// Fetch payments from the database
$filter = '';
if (isset($_GET['filter'])) {
    $filter = $_GET['filter'];
    switch ($filter) {
        case 'today':
            $payments_query = "SELECT * FROM payments WHERE DATE(payment_date) = CURDATE() ORDER BY payment_date DESC";
            break;
        case 'last_week':
            $payments_query = "SELECT * FROM payments WHERE payment_date >= DATE_SUB(CURDATE(), INTERVAL 7 DAY) ORDER BY payment_date DESC";
            break;
        default:
            $payments_query = "SELECT * FROM payments ORDER BY payment_date DESC";
            break;
    }
} else {
    $payments_query = "SELECT * FROM payments ORDER BY payment_date DESC";
}

$payments_result = mysqli_query($conn, $payments_query);

// Calculate totals
$total_payments_today = mysqli_fetch_assoc(mysqli_query($conn, "SELECT SUM(amount) AS total FROM payments WHERE DATE(payment_date) = CURDATE()"))['total'];
$total_payments_week = mysqli_fetch_assoc(mysqli_query($conn, "SELECT SUM(amount) AS total FROM payments WHERE payment_date >= DATE_SUB(CURDATE(), INTERVAL 7 DAY)"))['total'];
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Payments</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css">
    <!-- Toastr CSS -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">
    <!-- Font Awesome for icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>
<style>
#sidebar {
    display: none;
    position: fixed;
    left: 0;
    top: 60px;
    height: 100%;
    width: 150px;
    background-color: #f8f9fa;
    z-index: 1000;
    overflow-y: auto;
}

#sidebar.active {
    display: block;
}

#sidebar ul {
    padding: 0;
}

#sidebar .nav-item {
    list-style: none;
    margin: 0;
}

#sidebar .nav-link {
    color: #333;
    padding: 10px;
    display: block;
    text-decoration: none;
}

#sidebar .nav-link.active {
    background-color: #007bff;
    color: #fff;
    border-radius: 10px;
}

#sidebar .nav-link:hover {
    background-color: #007bff;
    color: #fff;
}

@media (min-width: 900px) {
    #sidebar {
        display: block;
        position: relative;
        width: 150px;
    }

    #sidebar.active {
        display: block;
    }
}

#toggleButton {
    display: block;
    position: fixed;
    top: 70px;
    right: 20px;
    z-index: 1100;
    background-color: #007bff;
    color: #fff;
    border: none;
    border-radius: 15px;
    padding: 10px;
}

@media (min-width: 900px) {
    #toggleButton {
        display: none;
    }
}
</style>

<body>

    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
        <div class="container-fluid">
            <a class="navbar-brand" href="#">Admin Dashboard</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav"
                aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="../logout.php">Logout</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
    <!-- Toggle Button -->
    <button id="toggleButton" onclick="toggleSidebar()">
        Menu
    </button>
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <nav id="sidebar" class="bg-light">
                <div class="position-sticky pt-3">
                    <ul class="nav flex-column">
                        <li class="nav-item mb-2">
                            <a class="nav-link" href="../admin_dashboard.php">
                                <i class="fas fa-tachometer-alt"></i>
                                Dashboard
                            </a>
                        </li>
                        <li class="nav-item mb-2">
                            <a class="nav-link" href="users.php">
                                <i class="fas fa-users"></i>
                                Users
                            </a>
                        </li>
                        <li class="nav-item mb-2">
                            <a class="nav-link" href="#">
                                <i class="fas fa-calendar-check"></i>
                                Bookings
                            </a>
                        </li>
                        <li class="nav-item mb-2">
                            <a class="nav-link" href="rooms.php">
                                <i class="fas fa-bed"></i>
                                Rooms
                            </a>
                        </li>
                        <li class="nav-item mb-2">
                            <a class="nav-link active" href="payments.php">
                                <i class="fas fa-money-check-alt"></i>
                                Payments
                            </a>
                        </li>
                        <li class="nav-item mb-2">
                            <a class="nav-link" href="staff.php">
                                <i class="fas fa-users-cog"></i>
                                Staff
                            </a>
                        </li>
                        <li class="nav-item mb-2">
                            <a class="nav-link" href="settings.php">
                                <i class="fas fa-cog"></i>
                                Settings
                            </a>
                        </li>
                    </ul>
                </div>
            </nav>

            <script>
            function toggleSidebar() {
                document.getElementById("sidebar").classList.toggle("active");
            }
            </script>
            <main class="col-sm-10 ms-sm-auto col-lg-10 px-md-4" style="margin-top: 80px;">
                <h2>Manage Payments</h2>

                <!-- Filter Buttons -->
                <div class="mb-4">
                    <a href="payments.php?filter=today" class="btn btn-outline-primary"><i
                            class="fas fa-calendar-day"></i>
                        Today's Payments</a>
                    <a href="payments.php?filter=last_week" class="btn btn-outline-primary"><i
                            class="fas fa-calendar-week"></i>
                        Last Week's Payments</a>
                    <a href="payments.php" class="btn btn-outline-primary"><i class="fas fa-calendar-alt"></i> All
                        Payments</a>
                    <a href="export_payments.php" class="btn btn-success float-end"><i class="fas fa-file-export"></i>
                        Export
                        Payments</a>
                </div>

                <!-- Payment Summary -->
                <div class="row mb-4">
                    <div class="col-md-6">
                        <div class="card text-white bg-info mb-3">
                            <div class="card-body">
                                <h5 class="card-title">Total Payments Today</h5>
                                <p class="card-text">$<?php echo number_format($total_payments_today, 2); ?></p>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="card text-white bg-success mb-3">
                            <div class="card-body">
                                <h5 class="card-title">Total Payments This Week</h5>
                                <p class="card-text">$<?php echo number_format($total_payments_week, 2); ?></p>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Payments Table -->
                <div class="table-responsive">
                    <table class="table table-bordered">
                        <thead class="table-light">
                            <tr>
                                <th>ID</th>
                                <th>Booking ID</th>
                                <th>Card Holder Name</th>
                                <th>Card Number</th>
                                <th>Amount</th>
                                <th>Payment Date</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while ($payment = mysqli_fetch_assoc($payments_result)) { ?>
                            <tr>
                                <td><?php echo $payment['id']; ?></td>
                                <td><?php echo $payment['booking_id']; ?></td>
                                <td><?php echo $payment['card_holder_name']; ?></td>
                                <td><?php echo str_repeat('*', 12) . substr($payment['card_number'], -4); // Mask card number ?>
                                </td>
                                <td><?php echo '$' . number_format($payment['amount'], 2); ?></td>
                                <td><?php echo date("M jS, Y g:i A", strtotime($payment['payment_date'])); ?></td>
                                <td>
                                    <div class="dropdown">
                                        <a class="dropdown-item"
                                            href="delete_payment.php?id=<?php echo $payment['id']; ?>"
                                            onclick="return confirm('Are you sure you want to delete this payment?');"><i
                                                class="fas fa-trash-alt"></i> Delete</a>
                                    </div>
                                </td>
                            </tr>
                            <?php } ?>
                        </tbody>
                    </table>
                </div>

            </main>
        </div>
    </div>


    <!-- jQuery -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"></script>

    <script>
    // Fill the edit modal with the payment details
    document.querySelectorAll('.edit-btn').forEach(button => {
        button.addEventListener('click', function() {
            const id = this.getAttribute('data-id');
            const amount = this.getAttribute('data-amount');
            const cardHolder = this.getAttribute('data-cardholder');
            const paymentDate = this.getAttribute('data-paymentdate');

            // Populate modal fields
            document.getElementById('payment_id').value = id;
            document.getElementById('amount').value = amount;
            document.getElementById('card_holder_name').value = cardHolder;
            document.getElementById('payment_date').value = new Date(paymentDate).toISOString().slice(0,
                16);
        });
    });
    </script>

    <script>
    <?php if ($message): ?>
    toastr.options = {
        "closeButton": true,
        "progressBar": true,
        "positionClass": "toast-top-right",
        "showDuration": "300",
        "hideDuration": "1000",
        "timeOut": "5000",
        "extendedTimeOut": "1000",
        "showEasing": "swing",
        "hideEasing": "linear",
        "showMethod": "fadeIn",
        "hideMethod": "fadeOut"
    };
    toastr.<?php echo $messageType === 'success' ? 'success' : 'error'; ?>('<?php echo $message; ?>');
    <?php endif; ?>
    </script>

</body>

</html>