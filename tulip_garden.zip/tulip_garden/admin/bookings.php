<?php
include '../config.php';
session_start();

// Check if admin is logged in
if (!isset($_SESSION['admin'])) {
    header('Location: ../login.php');
    exit;
}

$message = '';
$messageType = '';

// Fetch booking details from the database
$bookings_query = "
SELECT bookings.id, users.name AS guest_name, bookings.checkin_date, bookings.checkout_date, bookings.created_at AS order_date,
bookings.special_requests, bookings.status, rooms.type AS room_type, bookings.meal_type
FROM bookings
JOIN users ON bookings.user_id = users.id
JOIN rooms ON bookings.room_id = rooms.id
ORDER BY bookings.created_at DESC
";
$bookings_result = mysqli_query($conn, $bookings_query);

// Check if there is a message passed from the update_booking.php
if (isset($_SESSION['message'])) {
    $message = $_SESSION['message'];
    $messageType = $_SESSION['messageType'];
    unset($_SESSION['message']);
    unset($_SESSION['messageType']);
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Booking Details</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css">
    <!-- Font Awesome for icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <!-- Toastr CSS -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">
    <!-- Custom CSS -->
    <link rel="stylesheet" href="../styles.css">
    <style>
    .table-custom th {
        background-color: #f8f9fa;
        border-top: none;
    }

    .table-custom tbody tr {
        background-color: #fff;
        box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
        border-radius: 8px;
        overflow: hidden;
    }

    .table-custom tbody td {
        vertical-align: middle;
    }

    .dropdown-menu {
        min-width: 150px;
    }

    .dropdown-item {
        padding: 8px 16px;
    }

    .table img {
        border-radius: 50%;
        width: 40px;
        height: 40px;
    }

    .table-responsive {
        margin-top: 20px;
    }

    .table .btn-link {
        color: #000;
    }

    /* Popover styles */
    .popover-body {
        padding: 10px;
        font-size: 14px;
        color: #333;
    }

    .popover-header {
        font-weight: bold;
        background-color: #f8f9fa;
        border-bottom: 1px solid #ddd;
    }

    .popover {
        max-width: 200px;
        width: auto;
    }

    #sidebar {
        display: none;
        position: fixed;
        left: 0;
        top: 60px;
        height: 100%;
        width: 150px;
        background-color: #f8f9fa;
        z-index: 1000;
        overflow-y: auto;
    }

    #sidebar.active {
        display: block;
    }

    #sidebar ul {
        padding: 0;
    }

    #sidebar .nav-item {
        list-style: none;
        margin: 0;
    }

    #sidebar .nav-link {
        color: #333;
        padding: 10px;
        display: block;
        text-decoration: none;
    }

    #sidebar .nav-link.active {
        background-color: #007bff;
        color: #fff;
        border-radius: 10px;
    }

    #sidebar .nav-link:hover {
        background-color: #007bff;
        color: #fff;
    }

    @media (min-width: 900px) {
        #sidebar {
            display: block;
            position: relative;
            width: 150px;
        }

        #sidebar.active {
            display: block;
        }
    }

    #toggleButton {
        display: block;
        position: fixed;
        top: 70px;
        right: 20px;
        z-index: 1100;
        background-color: #007bff;
        color: #fff;
        border: none;
        border-radius: 15px;
        padding: 10px;
    }

    @media (min-width: 900px) {
        #toggleButton {
            display: none;
        }
    }
    </style>
</head>

<body>

    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
        <div class="container-fluid">
            <a class="navbar-brand" href="#">Admin Dashboard</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav"
                aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="../logout.php">Logout</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
    <!-- Toggle Button -->
    <button id="toggleButton" onclick="toggleSidebar()">
        Menu
    </button>

    <!-- Sidebar and Content -->
    <div class="container-fluid">
        <div class="row">

            <!-- Sidebar -->
            <nav id="sidebar" class="bg-light">
                <div class="position-sticky pt-3">
                    <ul class="nav flex-column">
                        <li class="nav-item mb-2">
                            <a class="nav-link" href="../admin_dashboard.php">
                                <i class="fas fa-tachometer-alt"></i>
                                Dashboard
                            </a>
                        </li>
                        <li class="nav-item mb-2">
                            <a class="nav-link" href="users.php">
                                <i class="fas fa-users"></i>
                                Users
                            </a>
                        </li>
                        <li class="nav-item mb-2">
                            <a class="nav-link active" href="#">
                                <i class="fas fa-calendar-check"></i>
                                Bookings
                            </a>
                        </li>
                        <li class="nav-item mb-2">
                            <a class="nav-link" href="rooms.php">
                                <i class="fas fa-bed"></i>
                                Rooms
                            </a>
                        </li>
                        <li class="nav-item mb-2">
                            <a class="nav-link" href="payments.php">
                                <i class="fas fa-money-check-alt"></i>
                                Payments
                            </a>
                        </li>
                        <li class="nav-item mb-2">
                            <a class="nav-link" href="staff.php">
                                <i class="fas fa-users-cog"></i>
                                Staff
                            </a>
                        </li>
                        <li class="nav-item mb-2">
                            <a class="nav-link" href="settings.php">
                                <i class="fas fa-cog"></i>
                                Settings
                            </a>
                        </li>
                    </ul>
                </div>
            </nav>

            <script>
            function toggleSidebar() {
                document.getElementById("sidebar").classList.toggle("active");
            }
            </script>


            <!-- Main Content -->
            <main class="col-sm-10 ms-sm-auto col-lg-10 px-md-4" style="margin-top: 80px;">
                <h2 class="mb-4">Booking Details</h2>
                <div class="table-responsive">
                    <table class="table table-hover table-bordered table-custom">
                        <thead class="table-light">
                            <tr>
                                <th>Guest</th>
                                <th>Order Date</th>
                                <th>Check In</th>
                                <th>Check Out</th>
                                <th>Meal Type</th>
                                <th>Special Request</th>
                                <th>Room Type</th>
                                <th>Status</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while ($booking = mysqli_fetch_assoc($bookings_result)) { ?>
                            <tr>
                                <td>
                                    <div class="d-flex align-items-center">
                                        <img src="images/user_icon.jpeg" alt="guest">
                                        <div class="ml-3">
                                            <strong><?php echo $booking['guest_name']; ?></strong><br>
                                            <small>#EMP-00025</small>
                                        </div>
                                    </div>
                                </td>
                                <td><?php echo date("M jS, Y g:i A", strtotime($booking['order_date'])); ?></td>
                                <td><?php echo date("M jS, Y g:i A", strtotime($booking['checkin_date'])); ?></td>
                                <td><?php echo date("M jS, Y g:i A", strtotime($booking['checkout_date'])); ?></td>
                                <td><?php echo $booking['meal_type']; ?></td>
                                <td>
                                    <button class="btn btn-secondary btn-sm" data-bs-toggle="popover"
                                        data-bs-content="<?php echo htmlspecialchars($booking['special_requests'], ENT_QUOTES); ?>">
                                        View Notes
                                    </button>
                                </td>
                                <td><?php echo $booking['room_type']; ?></td>
                                <td>
                                    <button
                                        class="btn btn-outline-danger btn-sm"><?php echo ucfirst($booking['status']); ?></button>
                                </td>
                                <td class="text-center">
                                    <div class="dropdown">
                                        <button class="btn btn-link text-dark p-0" type="button"
                                            id="dropdownMenuButton<?php echo $booking['id']; ?>"
                                            data-bs-toggle="dropdown" aria-expanded="false">
                                            <i class="fas fa-ellipsis-v"></i>
                                        </button>
                                        <ul class="dropdown-menu"
                                            aria-labelledby="dropdownMenuButton<?php echo $booking['id']; ?>">
                                            <li><a class="dropdown-item"
                                                    href="update_booking.php?id=<?php echo $booking['id']; ?>&status=confirmed">Confirm
                                                    Booking</a></li>
                                            <li><a class="dropdown-item"
                                                    href="update_booking.php?id=<?php echo $booking['id']; ?>&status=cancelled">Cancel
                                                    Booking</a></li>
                                            <li><a class="dropdown-item text-danger"
                                                    href="delete_booking.php?id=<?php echo $booking['id']; ?>"
                                                    onclick="return confirm('Are you sure you want to delete this booking?');">Delete
                                                    Booking</a></li>
                                        </ul>
                                    </div>
                                </td>
                            </tr>
                            <?php } ?>
                        </tbody>
                    </table>
                </div>
            </main>
        </div>
    </div>

    <!-- jQuery (required by Toastr) -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <!-- Toastr JS -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>
    <!-- Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"></script>

    <script>
    // Initialize Bootstrap popover
    $(function() {
        $('[data-bs-toggle="popover"]').popover({
            trigger: 'focus',
            placement: 'top'
        });
    });

    // Toastr Notification
    <?php if ($message): ?>
    toastr.options = {
        "closeButton": true,
        "progressBar": true,
        "positionClass": "toast-top-right",
        "showDuration": "300",
        "hideDuration": "1000",
        "timeOut": "5000",
        "extendedTimeOut": "1000",
        "showEasing": "swing",
        "hideEasing": "linear",
        "showMethod": "fadeIn",
        "hideMethod": "fadeOut"
    };
    toastr.<?php echo $messageType === 'success' ? 'success' : 'error'; ?>('<?php echo $message; ?>');
    <?php endif; ?>
    </script>

</body>

</html>