<?php
session_start();
include '../config.php';

// Check if admin is logged in
if (!isset($_SESSION['admin'])) {
    header('Location: ../login.php');
    exit;
}

// Check if the user ID is passed
if (isset($_GET['id'])) {
    $user_id = $_GET['id'];

    // Prepare the delete query
    $delete_query = "DELETE FROM users WHERE id = ?";
    $stmt = $conn->prepare($delete_query);
    $stmt->bind_param("i", $user_id);

    if ($stmt->execute()) {
        // If successful, set a success message
        $_SESSION['message'] = "User deleted successfully.";
        $_SESSION['messageType'] = "success";
    } else {
        // If there was an error, set an error message
        $_SESSION['message'] = "Error deleting user.";
        $_SESSION['messageType'] = "error";
    }
    $stmt->close();
} else {
    // If no user ID is passed, set an error message
    $_SESSION['message'] = "Invalid user ID.";
    $_SESSION['messageType'] = "error";
}

// Redirect back to the admin user management page
header('Location: users.php');
exit;
?>