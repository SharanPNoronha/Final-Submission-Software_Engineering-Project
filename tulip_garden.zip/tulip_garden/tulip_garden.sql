-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 11, 2024 at 01:17 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.1.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `tulip_garden`
--

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

CREATE TABLE `admins` (
  `id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admins`
--

INSERT INTO `admins` (`id`, `username`, `password`, `email`, `created_at`) VALUES
(1, 'admin', '$2y$10$/KHsY98GyihgZRLdcUR6luyjAzUmL0E.iaErpmClwKTlvyYY.brKC', 'admin@tulipgarden.com', '2024-08-03 19:58:47'),
(2, 'sharan', '$2y$10$/KHsY98GyihgZRLdcUR6luyjAzUmL0E.iaErpmClwKTlvyYY.brKC', 'sharanP@tulipgarden.com', '2024-09-01 12:56:18');

-- --------------------------------------------------------

--
-- Table structure for table `bookings`
--

CREATE TABLE `bookings` (
  `id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `room_id` int(11) DEFAULT NULL,
  `checkin_date` date NOT NULL,
  `checkout_date` date NOT NULL,
  `meal_type` varchar(255) DEFAULT NULL,
  `special_requests` text DEFAULT NULL,
  `status` enum('Pending','Confirmed','Cancelled') DEFAULT 'Pending',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `bookings`
--

INSERT INTO `bookings` (`id`, `user_id`, `room_id`, `checkin_date`, `checkout_date`, `meal_type`, `special_requests`, `status`, `created_at`) VALUES
(26, 18, 28, '2024-09-13', '2024-09-15', 'Vegetarian', 'abc', 'Cancelled', '2024-09-09 20:10:14'),
(27, 18, 28, '2024-09-16', '2024-09-17', 'Halal', 'fdfd', 'Confirmed', '2024-09-09 20:11:30'),
(28, 17, 29, '2024-09-13', '2024-09-15', 'Vegetarian', 'ewfw', 'Cancelled', '2024-09-09 20:59:53'),
(29, 21, 31, '2024-09-20', '2024-09-25', 'Vegetarian', 'Regular room service please', 'Confirmed', '2024-09-11 10:10:38'),
(30, 21, 27, '2024-09-26', '2024-09-27', 'Kosher', 'none', 'Confirmed', '2024-09-11 10:12:34'),
(31, 22, 30, '2024-09-19', '2024-09-20', 'Vegan', '', 'Confirmed', '2024-09-11 10:15:08'),
(32, 22, 32, '2024-10-10', '2024-10-16', 'Halal', 'avoid peanuts', 'Pending', '2024-09-11 10:17:05'),
(33, 20, 30, '2024-09-21', '2024-09-23', 'None', '', 'Confirmed', '2024-09-11 10:18:31'),
(34, 23, 29, '2024-10-09', '2024-10-12', 'Vegetarian', 'No eggs', 'Confirmed', '2024-09-11 10:22:14'),
(35, 24, 25, '2024-09-18', '2024-09-20', 'Vegetarian', '', 'Confirmed', '2024-09-11 10:24:53'),
(36, 24, 31, '2024-12-11', '2024-12-14', 'Halal', '', 'Confirmed', '2024-09-11 10:26:17'),
(38, 26, 36, '2024-09-18', '2024-09-19', 'Vegetarian', '', 'Confirmed', '2024-09-11 10:41:04'),
(39, 27, 35, '2024-09-30', '2024-10-02', 'Vegetarian', '', 'Confirmed', '2024-09-11 10:46:50'),
(40, 27, 30, '2024-09-28', '2024-09-29', 'Vegan', '', 'Pending', '2024-09-11 10:47:21');

-- --------------------------------------------------------

--
-- Table structure for table `payments`
--

CREATE TABLE `payments` (
  `id` int(11) NOT NULL,
  `booking_id` int(11) DEFAULT NULL,
  `card_holder_name` varchar(255) NOT NULL,
  `card_number` varchar(16) NOT NULL,
  `cvv` varchar(3) NOT NULL,
  `expiry_month` int(11) NOT NULL,
  `expiry_year` int(11) NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `payment_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `payments`
--

INSERT INTO `payments` (`id`, `booking_id`, `card_holder_name`, `card_number`, `cvv`, `expiry_month`, `expiry_year`, `amount`, `payment_date`, `created_at`) VALUES
(14, 27, 'Sharan', '254585167774', '666', 8, 2025, 450.00, '2024-09-09 20:18:16', '2024-09-09 20:18:16'),
(16, 29, 'Preetha', '457854856523', '341', 8, 2026, 2495.00, '2024-09-11 10:11:12', '2024-09-11 10:11:12'),
(17, 30, 'William', '165169148949', '455', 9, 2024, 220.00, '2024-09-11 10:13:09', '2024-09-11 10:13:09'),
(18, 31, 'Sharan Noronha', '986416516146', '255', 6, 2026, 500.00, '2024-09-11 10:15:30', '2024-09-11 10:15:30'),
(19, 33, 'Sonia', '457521454651', '546', 5, 2025, 1000.00, '2024-09-11 10:18:49', '2024-09-11 10:18:49'),
(20, 34, 'Mathias Hofmann', '147161316894', '658', 6, 2029, 1026.00, '2024-09-11 10:22:37', '2024-09-11 10:22:37'),
(21, 35, 'Walter', '772849681513', '564', 7, 2031, 400.00, '2024-09-11 10:25:23', '2024-09-11 10:25:23'),
(22, 36, 'Walter', '144654612313', '111', 1, 2029, 1497.00, '2024-09-11 10:26:41', '2024-09-11 10:26:41'),
(24, 38, 'Lethcia', '144984943135', '865', 1, 2027, 230.00, '2024-09-11 10:41:35', '2024-09-11 10:41:35'),
(25, 39, 'Jannet', '457964646351', '252', 3, 2028, 1200.00, '2024-09-11 10:47:39', '2024-09-11 10:47:39');

-- --------------------------------------------------------

--
-- Table structure for table `rooms`
--

CREATE TABLE `rooms` (
  `id` int(11) NOT NULL,
  `type` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `price_per_night` decimal(10,2) NOT NULL,
  `max_occupancy` int(11) NOT NULL,
  `image1` varchar(255) DEFAULT NULL,
  `image2` varchar(255) DEFAULT NULL,
  `image3` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `rooms`
--

INSERT INTO `rooms` (`id`, `type`, `description`, `price_per_night`, `max_occupancy`, `image1`, `image2`, `image3`, `created_at`) VALUES
(25, 'Double Occupancy- Standard Room', 'Located within 14 km of Chapora Fort and 16 km of Thivim railway station, FabHotel Springs provides rooms with air conditioning and a private bathroom in Sangolda. With free WiFi, this 3-star hotel offers room service and a 24-hour front desk. The hotel features family rooms.\r\n\r\nAll units at the hotel are equipped with a seating area, a flat-screen TV with cable channels and a private bathroom with free toiletries and a shower. The units include a wardrobe.\r\n\r\nGuests at FabHotel Springs can enjoy a continental breakfast.\r\n\r\nBasilica Of Bom Jesus is 16 km from the accommodation, while Church of Saint Cajetan is 17 km away. The nearest airport is Dabolim Airport, 33 km from FabHotel Springs.', 200.00, 2, 'images/download (2).jpeg', 'images/download (3).jpeg', 'images/download (7).jpeg', '2024-09-09 19:51:40'),
(26, 'Single Room - Standard', 'Our hotel is located in Mitte, right next to the domes at Gendarmenmarkt and the Rausch Chocolate House. Some rooms offer views of the Reichstag dome and our hotel is equipped with an indoor pool, a fitness center, a sauna and a spa. Checkpoint Charlie, the Brandenburg Gate and the Berlin Wall are within a three-kilometer radius.', 120.00, 1, 'images/297351588.jpg', 'images/297350452.jpg', 'images/547293426.jpg', '2024-09-09 19:58:32'),
(27, 'Double Occupancy- Luxury Suite with 2 single bed', 'Our hotel overlooking Köpenick Square is less than a five-minute walk from the luxury boutiques, restaurants and showrooms of Kurfürstendamm. The Kaiser Wilhelm Memorial Church and the Zoological Garden are also less than a kilometer away. Our hotel is just five minutes from the city center and offers 11 meeting rooms with versatile event space for up to 500 guests.', 220.00, 2, 'images/143397264.jpg', 'images/download (5).jpeg', 'images/download (8).jpeg', '2024-09-09 20:00:34'),
(28, 'Suite Luxury with 2 Large Rooms', 'Located in Berlin, 2 km from Messe Berlin, 4.1 km from Kurfürstendamm and 4.6 km from Zoologischer Garten Underground Station, SC 5 Cozy Family & Business Flair welcomes you - Rockchair Apartments offers accommodation with a balcony and free WiFi. Housed in a building dating from 2017, this apartment is 7.4 km from Berlin Central Station and 7.4 km from Brandenburg Gate. This apartment with a terrace and city views includes 2 bedrooms, a living room, a flat-screen TV, a well-equipped kitchen with a fridge and a dishwasher, and 1 bathroom with a shower. Towels and bed linen are provided in this apartment. Reichstag is 7.5 km from SC 5 Cozy Family & Business Flair welcomes you - Rockchair Apartments, while Berliner Philharmonie is 7.7 km away. The nearest airport is Berlin Brandenburg Airport, 28 km from SC 5 Cozy Family & Business Flair welcomes you - Rockchair Apartments.', 450.00, 4, 'images/188929370.jpg', 'images/251885574-new1.jpg', 'images/251885587-new2.jpg', '2024-09-09 20:02:31'),
(29, 'Double Deluxe Room', 'This hotel is well located in the city. Alexanderplatz and the famous Friedrichstrasse can be reached in just a few minutes by public transport. It is located in the Friedrichshain-Kreuzberg district, close to Warschauer Strasse train station, the East Side Gallery and the O2 Arena. This colorful area is a popular and trendy hotspot. Discover the numerous restaurants, bars, cafés and shops in the area surrounding the hotel. The center of Berlin is just a few minutes away. The property offers various room categories. All rooms are bright, friendly and decorated with modern furniture. The rooms have a private bathroom or access to a private bathroom with a shower.', 342.00, 2, 'images/594932330.jpg', 'images/550782054.jpg', 'images/550782108.jpg', '2024-09-09 20:04:57'),
(30, 'Deluxe Roof Top Luxury Room', 'Street view, 47-inch TV, desk, ergonomic chair, minibar\r\n\r\nEnjoy your stay in this elegant room with king-size bed, decorated in rich, warm colors and overlooking the street. Relax after a busy day with a fresh cup of tea or coffee or one of the many refreshments from the minibar.\r\n\r\nStay connected with Wi-Fi or choose from many satellite channels on the flat-screen TV. The comfortable king-size bed and black-out curtains ensure a good night\'s sleep.\r\n\r\nThis room also features a desk with ergonomic chair and individually controlled air conditioning. For 2 adults.', 500.00, 2, 'images/251885574.jpg', 'images/rooftop2.jpeg', 'images/download (14).jpeg', '2024-09-09 20:07:19'),
(31, '3 Room Suite with Beautiful Roof top view', 'Located in Berlin, 2 km from Messe Berlin, 4.1 km from Kurfürstendamm and 4.6 km from Zoologischer Garten Underground Station, SC 5 Cozy Family & Business Flair welcomes you - Rockchair Apartments offers accommodation with a balcony and free WiFi. Housed in a building dating from 2017, this apartment is 7.4 km from Berlin Central Station and 7.4 km from Brandenburg Gate. This apartment with a terrace and city views includes 2 bedrooms, a living room, a flat-screen TV, a well-equipped kitchen with a fridge and a dishwasher, and 1 bathroom with a shower. Towels and bed linen are provided in this apartment. Reichstag is 7.5 km from SC 5 Cozy Family & Business Flair welcomes you - Rockchair Apartments, while Berliner Philharmonie is 7.7 km away. The nearest airport is Berlin Brandenburg Airport, 28 km from SC 5 Cozy Family & Business Flair welcomes you - Rockchair Apartments.', 499.00, 6, 'images/252413691.jpg', 'images/rooftop2-new1.jpeg', 'images/download (10)-new1.jpeg', '2024-09-09 20:50:17'),
(32, 'Triple sharing Large room - Standard', 'This room in Berlin\'s vibrant Friedrichshain district offers free WiFi and easy keyless access. The bars and restaurants of Simon-Dach-Straße are a 3-minute walk away. Luxoise Apartments feature designer interiors with parquet floors and a fully equipped kitchen. All apartments also feature a flat-screen TV, DVD player and a large bathroom with a bathtub and washing machine. Two of the apartments have a furnished terrace. Ostkreuz Train Station is a 15-minute walk from Luxoise Apartments and offers direct train connections to Berlin Brandenburg Airport. Alexanderplatz can be reached by underground from Samariterstraße Underground Station, a 7-minute walk away. Guests can also visit the popular Sunday flea market at Boxhagener Platz, just 200 metres away.', 300.00, 3, 'images/251885587.jpg', 'images/154439520.jpg', 'images/154477450.jpg', '2024-09-11 09:59:10'),
(34, 'Single Standard Room', 'This hotel in central Berlin offers elegant rooms and a spa with indoor pool. The hotel is located on the Friedrichstrasse shopping street, just 300 metres from the underground station. The spacious, air-conditioned rooms and suites at the Maritim proArte Hotel Berlin feature Italian-style furniture, satellite TV and a laptop safe. Free Wi-Fi is available throughout the hotel. The hotel\'s 2 restaurants serve international cuisine and typical Berlin delicacies in a cosy atmosphere. The Checkpoint bar spoils you with an exquisite selection of cocktails, long drinks and high-quality spirits, as well as burgers, snacks and nibbles. The Maritim\'s spa includes a pool, sauna, steam bath and gym. Massages and beauty treatments are also available. The famous Unter den Linden boulevard with the Brandenburg Gate is just 100 metres away. The UNESCO World Heritage Museum Island is just 1.5 km from the hotel. Other attractions within walking distance include the Friedrichstadt-Palast, the Admiralspalast, the Komische Oper, boat tour operators and Hackescher Markt.', 200.00, 1, 'images/469387221.jpg', 'images/469389181.jpg', 'images/473409251.jpg', '2024-09-11 10:05:57'),
(35, 'Deluxe Room', 'This property requires online check-in one day before arrival. Centrally located in the trendy Mitte district of Berlin, Apartments Rosenthal Residence offers pet-friendly, self-catering accommodation with elegant, modern décor. Museum Island is just 1 km away. The tram and train station are right outside the apartments. Alexanderplatz is 1.1 km away, while Berlin TV Tower is 1.2 km from Apartments Rosenthal Residence. Tegel Airport is 8 km away. The accommodation features a seating area. Some units include a smart TV with cable channels and Blu-ray player. Each unit is fitted with a private bathroom with a shower. Towels are provided. All apartments have a dining area and a kitchen equipped with a microwave on request, toaster and fridge, as well as a stovetop and coffee machine. If you prefer to eat out, there are many restaurants within about 100 m. Bicycles can be rented for a daily fee.\r\n\r\nFamilies particularly appreciate the location – they rated it 9.3 for a stay with children.', 600.00, 4, 'images/229919172.jpg', 'images/238605202.jpg', 'images/284257622.jpg', '2024-09-11 10:09:22'),
(36, 'Single Deluxe', 'The stylish BIG MAMA Berlin is located in the north of Berlin, 600 meters from Osloer Straße Underground Station, which offers direct connections to central Berlin in 10 minutes. The hotel features a terrace, a garden and free WiFi. Opened in December 2013, BIG MAMA Berlin offers apartments, dormitories and hotel rooms, all decorated in a modern style. All rooms have a bathroom and a seating area. A fresh breakfast buffet is available for an additional charge. There is also a good selection of restaurants and bars within a 10-minute walk from BIG MAMA Berlin. The Brandenburg Gate is 6 km away. Bicycles can be rented on site. Gesundbrunnen Train Station is 1.5 km away, offering direct connections to Berlin Central Station in 5 minutes. Berlin Schönefeld Airport is a 35-minute drive from BIG MAMA Berlin.', 230.00, 1, 'images/387176913.jpg', 'images/535644340.jpg', 'images/387169476.jpg', '2024-09-11 10:38:16'),
(37, 'Double Occupancy Room', 'This 4-star hotel is located in the heart of western Berlin, just 200 metres from Zoologischer Garten Train Station. Hotel Indigo Berlin - Ku\'damm offers free WiFi and an on-site gym. Rooms at Hotel Indigo Berlin - Ku\'damm feature bright, modern interiors with wooden floors. All rooms are air-conditioned and have a bathroom with a rain shower, bathrobe and Aveda toiletries. Hotel Indigo Berlin - Ku\'damm is a 5-minute walk from the historic Berlin Memorial Church and the Kurfürstendamm shopping street. The world-famous KaDeWe department store is a 10-minute walk away.', 190.00, 2, 'images/246396613.jpg', 'images/405960004.jpg', 'images/246544591.jpg', '2024-09-11 10:59:54');

-- --------------------------------------------------------

--
-- Table structure for table `room_images`
--

CREATE TABLE `room_images` (
  `id` int(11) NOT NULL,
  `room_id` int(11) DEFAULT NULL,
  `image_path` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `staff`
--

CREATE TABLE `staff` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone` varchar(15) DEFAULT NULL,
  `position` varchar(255) DEFAULT NULL,
  `salary` decimal(10,2) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `staff`
--

INSERT INTO `staff` (`id`, `name`, `email`, `phone`, `position`, `salary`, `created_at`) VALUES
(2, 'John', 'john@tulipgarden.com', '01764528653', 'Manager', 5500.00, '2024-08-03 19:12:00'),
(3, 'Steev', 'steev@tulipgarden.com', '01742579854', 'chef', 2900.00, '2024-08-15 20:08:15'),
(4, 'Preeth', 'preeth@tulipgarden.com', '01764524585', 'Receptionist', 3000.00, '2024-08-16 18:08:27'),
(5, 'oswald', 'oswald@tulipgarden.com', '01734645873', 'security gaurd', 2000.00, '2024-08-25 10:00:15'),
(6, 'Jassy', 'jassy@tulipgarden.com', '01754587584', 'room service', 2500.00, '2024-09-03 12:07:25'),
(7, 'Wilson', 'wilson@tulipgarden.com', '01754534166', 'Waiter', 2000.00, '2024-09-11 10:31:01'),
(8, 'Allwyn', 'Allwyn@tulipgarden.com', '017514622625', 'Kitchen Helper', 1600.00, '2024-09-11 10:31:42'),
(9, 'Charlotte', 'charlotte@tulipgarden.com', '01754646282', 'Working Student', 1200.00, '2024-09-11 10:32:41'),
(10, 'Jackson', 'jackson@tulipgarden.com', '01754687229', 'Sales Manager', 4000.00, '2024-09-11 10:33:12'),
(11, 'Tony', 'tony@tulipgarden.com', '01754623599', 'Room Service', 2500.00, '2024-09-11 10:34:11'),
(12, 'Nicolas', 'Nicolas@tulipgarden.com', '017564382554', 'CEO', 6000.00, '2024-09-11 10:35:18'),
(13, 'Pearl', 'pearl@tulipgarden.com', '017549284159', 'Chef', 5000.00, '2024-09-11 11:16:28');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `phone` varchar(15) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `phone`, `created_at`) VALUES
(17, 'Sharan', 'sharan_user@outlook.com', '$2y$10$eZTWWAMqqZxFbaOo3/Z.iOW/MSvJAal30iUqahliS4ZNJt9OAETJm', '0173123234456', '2024-09-06 10:00:13'),
(18, 'jaspreeth', 'jaspreeth@gmail.com', '$2y$10$/RLWRirNMjHn.eSRbiW2L.6UMZriGBeXofnCRmzR53IQWwrQ60kl6', '01485752155', '2024-09-09 19:43:18'),
(19, 'Angela', 'angela@outlook.com', '$2y$10$fAGyLDENggOEqXpGohcezur4xFojfF7/7mzFB7oY03fht1E/p2WnS', '01345785455', '2024-09-11 09:39:09'),
(20, 'Sonia', 'sonia@gmail.com', '$2y$10$mmtr2JpQUjb14/z1LZoayentZuMRENGT3hFFLdHnWL3ZnZ0eD79zG', '01754852445', '2024-09-11 09:40:50'),
(21, 'William', 'william@icloud.com', '$2y$10$julMgYkBOgXUElsCs1oPQufRlU.4orIRQQ6fD20iqceHmoBi3JHbC', '01765462457', '2024-09-11 09:42:39'),
(22, 'Sharan Noronha', 'noronhaShar@icloud.com', '$2y$10$zyVYEwtJ2BRgjzi6uGLbKevVHFJsweq.kOX.GKkTL2FSd/YGJhCpG', '017645284695', '2024-09-11 10:14:37'),
(23, 'Mathias', 'mathias@gmail.com', '$2y$10$eqoae1erwtqdcF7Sqg228eXl8RJ7GasZg7FwFpS8XEDpAU85hGjI.', '0175485645852', '2024-09-11 10:19:57'),
(24, 'Walter', 'walter@outlook.com', '$2y$10$7Ous5MeLYc1sPrGCMKxrJ.FWPWz7G/TLZL1IIFLNjfU1/Ri.5gaIG', '017546824653', '2024-09-11 10:24:28'),
(26, 'Lethcia', 'Lethcia@gmail.com', '$2y$10$WWQFXq1kdD9TOsunQFIS8ORRw1qBF2ie5W5Ze4B7rc28g0peD45we', '01754856452', '2024-09-11 10:39:37'),
(27, 'Jannet', 'Jannet@gmail.com', '$2y$10$KrkNkjtLXJfGCQDmZuOZ5OyfzQRAZC4K6/p1AKmQWmmg3BZW6OYtW', '013458546882', '2024-09-11 10:46:05');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `bookings`
--
ALTER TABLE `bookings`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `room_id` (`room_id`);

--
-- Indexes for table `payments`
--
ALTER TABLE `payments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `booking_id` (`booking_id`);

--
-- Indexes for table `rooms`
--
ALTER TABLE `rooms`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `room_images`
--
ALTER TABLE `room_images`
  ADD PRIMARY KEY (`id`),
  ADD KEY `room_id` (`room_id`);

--
-- Indexes for table `staff`
--
ALTER TABLE `staff`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admins`
--
ALTER TABLE `admins`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `bookings`
--
ALTER TABLE `bookings`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=41;

--
-- AUTO_INCREMENT for table `payments`
--
ALTER TABLE `payments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT for table `rooms`
--
ALTER TABLE `rooms`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=38;

--
-- AUTO_INCREMENT for table `room_images`
--
ALTER TABLE `room_images`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `staff`
--
ALTER TABLE `staff`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `bookings`
--
ALTER TABLE `bookings`
  ADD CONSTRAINT `bookings_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `bookings_ibfk_2` FOREIGN KEY (`room_id`) REFERENCES `rooms` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `payments`
--
ALTER TABLE `payments`
  ADD CONSTRAINT `payments_ibfk_1` FOREIGN KEY (`booking_id`) REFERENCES `bookings` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `room_images`
--
ALTER TABLE `room_images`
  ADD CONSTRAINT `room_images_ibfk_1` FOREIGN KEY (`room_id`) REFERENCES `rooms` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
