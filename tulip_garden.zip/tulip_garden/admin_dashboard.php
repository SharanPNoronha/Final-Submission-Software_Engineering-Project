<?php
include './config.php';
session_start();

$message = '';
$messageType = '';

// Check if admin is logged in
if (!isset($_SESSION['admin'])) {
    header('Location: login.php');
    exit;
}

// Fetch statistics from the database

// Total Sales
$total_sales_query = "SELECT SUM(amount) as total_sales FROM payments";
$total_sales_result = mysqli_query($conn, $total_sales_query);
$total_sales = mysqli_fetch_assoc($total_sales_result)['total_sales'];

// Total Orders
$total_orders_query = "SELECT COUNT(*) as total_orders FROM bookings";
$total_orders_result = mysqli_query($conn, $total_orders_query);
$total_orders = mysqli_fetch_assoc($total_orders_result)['total_orders'];

// Total Products Sold (Rooms)
$product_sold_query = "SELECT COUNT(DISTINCT room_id) as product_sold FROM bookings";
$product_sold_result = mysqli_query($conn, $product_sold_query);
$product_sold = mysqli_fetch_assoc($product_sold_result)['product_sold'];

// New Customers (Last 30 Days)
$new_customers_query = "SELECT COUNT(*) as new_customers FROM users WHERE created_at > DATE_SUB(NOW(), INTERVAL 30 DAY)";
$new_customers_result = mysqli_query($conn, $new_customers_query);
$new_customers = mysqli_fetch_assoc($new_customers_result)['new_customers'];

// Customer Satisfaction (Booking Status)
$customer_satisfaction_query = "SELECT status, COUNT(*) as count FROM bookings GROUP BY status";
$customer_satisfaction_result = mysqli_query($conn, $customer_satisfaction_query);
$customer_satisfaction = [];
while ($row = mysqli_fetch_assoc($customer_satisfaction_result)) {
    $customer_satisfaction[$row['status']] = $row['count'];
}

// Daily Revenue Data
$daily_revenue_query = "SELECT SUM(amount) as revenue, DATE_FORMAT(payment_date, '%Y-%m-%d') as day FROM payments GROUP BY day ORDER BY day ASC";
$daily_revenue_result = mysqli_query($conn, $daily_revenue_query);

$daily_revenue = [];
while ($row = mysqli_fetch_assoc($daily_revenue_result)) {
    $daily_revenue[$row['day']] = $row['revenue'];
}

// Convert the array to the correct format for Chart.js
$revenue_labels = json_encode(array_keys($daily_revenue));
$revenue_data = json_encode(array_values($daily_revenue));


?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css">
    <!-- Font Awesome for icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <!-- Toastr CSS -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">
    <!-- Custom CSS -->
    <link rel="stylesheet" href="styles.css">
    <!-- Chart.js -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<style>
#dash-main-top {
    margin-top: 100px;
}

.card-stat {
    display: flex;
    align-items: center;
    padding: 15px;
    background-color: #f8f9fa;
    border-radius: 8px;
    margin-bottom: 20px;
}

.card-stat .left-div {
    font-size: 2em;
    color: #343a40;
    margin-right: 15px;
}

.card-stat .right-div h3 {
    margin: 0;
    font-size: 1.2em;
    color: #343a40;
}

.card-stat .right-div p {
    margin: 0;
    font-size: 1.5em;
    color: #343a40;
}

.container-fluid {
    padding-left: 0;
    padding-right: 0;
}

.table-responsive {
    margin-top: 20px;
}

.card {
    box-shadow: 0 0 15px rgba(0, 0, 0, 0.1);
}

.navbar-nav .nav-item .nav-link.active {
    color: #007bff;
}

/* Chart styling */
canvas {
    background: white;
    border-radius: 8px;
    padding: 10px;
}

#sidebar {
    display: none;
    position: fixed;
    left: 15px;
    top: 60px;
    height: 100%;
    width: 150px;
    background-color: #f8f9fa;
    z-index: 1000;
    overflow-y: auto;
    padding-left: 10px;
}

#sidebar.active {
    display: block;
}

#sidebar ul {
    padding: 0;
}

#sidebar .nav-item {
    list-style: none;
    margin: 0;
}

#sidebar .nav-link {
    color: #333;
    padding: 10px;
    display: block;
    text-decoration: none;
}

#sidebar .nav-link.active {
    background-color: #007bff;
    color: #fff;
    border-radius: 10px;
}

#sidebar .nav-link:hover {
    background-color: #007bff;
    color: #fff;
}

@media (min-width: 900px) {
    #sidebar {
        display: block;
        position: relative;
        width: 150px;
    }

    #sidebar.active {
        display: block;
    }
}

#toggleButton {
    display: block;
    position: fixed;
    top: 70px;
    right: 20px;
    z-index: 1100;
    background-color: #007bff;
    color: #fff;
    border: none;
    border-radius: 15px;
    padding: 10px;
}

@media (min-width: 900px) {
    #toggleButton {
        display: none;
    }
}
</style>

<body>

    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
        <div class="container-fluid">
            <a class="navbar-brand" href="#">Admin Dashboard</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav"
                aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="logout.php">Logout</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <button id="toggleButton" onclick="toggleSidebar()">
        Menu
    </button>

    <!-- Sidebar and Content -->
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <!-- Sidebar -->
            <nav id="sidebar" class="bg-light">
                <div class="position-sticky pt-3">
                    <ul class="nav flex-column">
                        <li class="nav-item mb-2">
                            <a class="nav-link active" href="../admin_dashboard.php">
                                <i class="fas fa-tachometer-alt"></i>
                                Dashboard
                            </a>
                        </li>
                        <li class="nav-item mb-2">
                            <a class="nav-link" href="admin/users.php">
                                <i class="fas fa-users"></i>
                                Users
                            </a>
                        </li>
                        <li class="nav-item mb-2">
                            <a class="nav-link" href="admin/bookings.php">
                                <i class="fas fa-calendar-check"></i>
                                Bookings
                            </a>
                        </li>
                        <li class="nav-item mb-2">
                            <a class="nav-link" href="admin/rooms.php">
                                <i class="fas fa-bed"></i>
                                Rooms
                            </a>
                        </li>
                        <li class="nav-item mb-2">
                            <a class="nav-link" href="admin/payments.php">
                                <i class="fas fa-money-check-alt"></i>
                                Payments
                            </a>
                        </li>
                        <li class="nav-item mb-2">
                            <a class="nav-link" href="admin/staff.php">
                                <i class="fas fa-users-cog"></i>
                                Staff
                            </a>
                        </li>
                        <li class="nav-item mb-2">
                            <a class="nav-link" href="admin/settings.php">
                                <i class="fas fa-cog"></i>
                                Settings
                            </a>
                        </li>
                    </ul>
                </div>
            </nav>

            <script>
            function toggleSidebar() {
                document.getElementById("sidebar").classList.toggle("active");
            }
            </script>
            <!-- Main Content -->
            <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4" id="dash-main-top">
                <div class="row mb-4">
                    <div class="col-lg-3">
                        <div class="card-stat">
                            <div class="left-div">
                                <i class="fas fa-dollar-sign" id="stat-icon"></i>
                            </div>
                            <div class="right-div">
                                <h3 class="card-title">Sales</h3>
                                <p class="card-text">$<?php echo number_format($total_sales, 2); ?></p>
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-3">
                        <div class="card-stat">
                            <div class="left-div">
                                <i class="fas fa-shopping-cart" id="stat-icon"></i>
                            </div>
                            <div class="right-div">
                                <h3 class="card-title">Bookings</h3>
                                <p class="card-text"><?php echo $total_orders; ?></p>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3">
                        <div class="card-stat">
                            <div class="left-div">
                                <i class="fas fa-box-open" id="stat-icon"></i>
                            </div>
                            <div class="right-div">
                                <h3 class="card-title">Rooms Sold</h3>
                                <p class="card-text"><?php echo $product_sold; ?></p>
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-3">
                        <div class="card-stat">
                            <div class="left-div">
                                <i class="fas fa-user-plus" id="stat-icon"></i>
                            </div>
                            <div class="right-div">
                                <h3 class="card-title">New Customers</h3>
                                <p class="card-text"><?php echo $new_customers; ?></p>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Charts Section -->
                <div class="row">
                    <div class="col-md-6 mb-4">
                        <div class="card">
                            <div class="card-body">
                                <h5 class="card-title">Daily Revenue</h5>
                                <canvas id="dailyRevenueChart" style="height: 300px;"></canvas>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-6 mb-4">
                        <div class="card">
                            <div class="card-body">
                                <h5 class="card-title">Customer Satisfaction</h5>
                                <canvas id="customerSatisfactionChart" style="height: 300px;"></canvas>
                            </div>
                        </div>
                    </div>
                </div>
            </main>
        </div>
    </div>

    <script>
    // Daily Revenue Chart
    var ctx = document.getElementById('dailyRevenueChart').getContext('2d');
    var dailyRevenueChart = new Chart(ctx, {
        type: 'line', // Line chart for daily revenue
        data: {
            labels: <?php echo $revenue_labels; ?>,
            datasets: [{
                label: 'Daily Revenue',
                data: <?php echo $revenue_data; ?>,
                backgroundColor: 'rgba(75, 192, 192, 0.2)',
                borderColor: 'rgba(75, 192, 192, 1)',
                borderWidth: 1
            }]
        },
        options: {
            scales: {
                y: {
                    beginAtZero: true
                }
            }
        }
    });


    // Customer Satisfaction Chart
    var ctx = document.getElementById('customerSatisfactionChart').getContext('2d');
    var customerSatisfactionChart = new Chart(ctx, {
        type: 'pie',
        data: {
            labels: ['Confirmed', 'Pending', 'Cancelled'],
            datasets: [{
                label: 'Customer Satisfaction',
                data: [
                    <?php echo $customer_satisfaction['Confirmed'] ?? 0; ?>,
                    <?php echo $customer_satisfaction['Pending'] ?? 0; ?>,
                    <?php echo $customer_satisfaction['Cancelled'] ?? 0; ?>
                ],
                backgroundColor: [
                    'rgba(54, 162, 235, 0.6)',
                    'rgba(255, 206, 86, 0.6)',
                    'rgba(255, 99, 132, 0.6)'
                ],
                borderColor: [
                    'rgba(54, 162, 235, 1)',
                    'rgba(255, 206, 86, 1)',
                    'rgba(255, 99, 132, 1)'
                ],
                borderWidth: 1
            }]
        },
        options: {
            responsive: true,
            plugins: {
                legend: {
                    position: 'top',
                },
                tooltip: {
                    enabled: true
                }
            }
        }
    });

    // Toastr Notification
    <?php if ($message): ?>
    toastr.options = {
        "closeButton": true,
        "progressBar": true,
        "positionClass": "toast-top-right",
        "showDuration": "300",
        "hideDuration": "1000",
        "timeOut": "5000",
        "extendedTimeOut": "1000",
        "showEasing": "swing",
        "hideEasing": "linear",
        "showMethod": "fadeIn",
        "hideMethod": "fadeOut"
    };
    toastr.<?php echo $messageType === 'success' ? 'success' : 'error'; ?>('<?php echo $message; ?>');
    <?php endif; ?>
    </script>

    <!-- jQuery (required by Toastr) -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <!-- Toastr JS -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>
    <!-- Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>