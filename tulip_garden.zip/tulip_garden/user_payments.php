<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
session_start();
include 'config.php';

// Check if the user is logged in
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

$user_id = $_SESSION['user_id'];

// Filter logic
// Filter logic
$filter = '';
if (isset($_GET['filter'])) {
    $filter = $_GET['filter'];
    switch ($filter) {
        case 'today':
            $payments_query = "
                SELECT payments.*, bookings.user_id 
                FROM payments 
                JOIN bookings ON payments.booking_id = bookings.id 
                WHERE bookings.user_id = ? 
                AND DATE(payments.payment_date) = CURDATE() 
                ORDER BY payments.payment_date DESC";
            break;
        case 'last_week':
            $payments_query = "
                SELECT payments.*, bookings.user_id 
                FROM payments 
                JOIN bookings ON payments.booking_id = bookings.id 
                WHERE bookings.user_id = ? 
                AND payments.payment_date >= DATE_SUB(CURDATE(), INTERVAL 7 DAY) 
                ORDER BY payments.payment_date DESC";
            break;
        default:
            $payments_query = "
                SELECT payments.*, bookings.user_id 
                FROM payments 
                JOIN bookings ON payments.booking_id = bookings.id 
                WHERE bookings.user_id = ? 
                ORDER BY payments.payment_date DESC";
            break;
    }
} else {
    $payments_query = "
        SELECT payments.*, bookings.user_id 
        FROM payments 
        JOIN bookings ON payments.booking_id = bookings.id 
        WHERE bookings.user_id = ? 
        ORDER BY payments.payment_date DESC";
}

// Execute the query
$stmt = $conn->prepare($payments_query);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$payments_result = $stmt->get_result();
$stmt->close();


?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Payments -Tulip Garden</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css">
    <!-- Font Awesome for icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <!-- Custom CSS -->
    <link rel="stylesheet" href="styles.css">
    <style>
    /* General styling */
    body {
        background-color: #f7f7f7;
        font-family: 'Poppins', sans-serif;
    }

    .navbar-brand {
        font-weight: bold;
    }

    .jumbotron {
        background: linear-gradient(to right, #4e54c8, #8f94fb);
        color: white;
        border-radius: 10px;
        padding: 50px;
        margin-bottom: 30px;
    }

    /* Search bar styling */
    .search-bar {
        margin: 20px 0;
    }

    /* Luxury table styling */
    .table {
        background-color: #ffffff;
        border-radius: 10px;
        box-shadow: 0 8px 15px rgba(0, 0, 0, 0.1);
        margin-top: 20px;
    }

    .table th,
    .table td {
        vertical-align: middle;
        text-align: center;
    }

    /* Filter buttons */
    .filter-btn {
        background-color: #4e54c8;
        color: white;
        margin-left: 10px;
        border-radius: 5px;
    }

    .filter-btn:hover {
        background-color: #8f94fb;
    }

    /* Footer styling */
    footer {
        background-color: #343a40;
        color: white;
        padding: 20px;
        text-align: center;
        margin-top: 40px;
    }
    </style>
</head>

<body>

    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container-fluid">
            <a class="navbar-brand" href="user_home.php">Tulip Garden</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav"
                aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="user_home.php">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="mybookings.php">My Bookings</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="user_rooms.php">Rooms</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="user_payments.php">Payments</a>
                    </li>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="profileDropdown" role="button"
                            data-bs-toggle="dropdown" aria-expanded="false">
                            <i class="fas fa-user"></i>
                        </a>
                        <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="profileDropdown">
                            <li><a class="dropdown-item" href="profile.php"><i class="fas fa-user-edit"></i> Edit
                                    Profile</a></li>
                            <li><a class="dropdown-item" href="logout.php"><i class="fas fa-sign-out-alt"></i>
                                    Logout</a></li>
                        </ul>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <!-- Hero Section -->
    <div class="container mt-5">
        <div class="jumbotron text-center p-5">
            <h1>Your Payments</h1>
            <p>Keep track of your payment history with us.</p>
        </div>
    </div>

    <!-- Filter Buttons -->
    <div class="container">
        <div class="d-flex justify-content-end mb-3">
            <a href="user_payments.php?filter=today" class="btn btn-outline-primary"><i class="fas fa-calendar-day"></i>
                Today's Payments</a>
            <a href="user_payments.php?filter=last_week" class="btn btn-outline-primary"><i
                    class="fas fa-calendar-week"></i> Last Week's Payments</a>
            <a href="user_payments.php" class="btn btn-outline-primary"><i class="fas fa-calendar-alt"></i> All
                Payments</a>
        </div>
    </div>

    <!-- Payments Table -->
    <div class="container">
        <div class="table-responsive">
            <table class="table table-bordered">
                <thead class="table-light">
                    <tr>
                        <th>Payment ID</th>
                        <th>Booking ID</th>
                        <th>Amount</th>
                        <th>Payment Date</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($payment = mysqli_fetch_assoc($payments_result)) { ?>
                    <tr>
                        <td><?php echo $payment['id']; ?></td>
                        <td><?php echo $payment['booking_id']; ?></td>
                        <td><?php echo '$' . number_format($payment['amount'], 2); ?></td>
                        <td><?php echo date("M jS, Y g:i A", strtotime($payment['payment_date'])); ?></td>
                    </tr>
                    <?php } ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- Footer -->
    <footer style="position:absolute; bottom:0%; width:100%;">
        <p>&copy; <?php echo date("Y"); ?> Tulip Garden. All Rights Reserved.</p>
    </footer>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"></script>

</body>

</html>