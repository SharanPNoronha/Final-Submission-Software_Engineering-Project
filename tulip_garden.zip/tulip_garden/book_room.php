<?php
session_start();
include 'config.php';

// Check if the user is logged in
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

$user_id = $_SESSION['user_id'];
$room_id = $_GET['id'];

// Fetch room details
$room_query = "SELECT * FROM rooms WHERE id = ?";
$stmt = $conn->prepare($room_query);
$stmt->bind_param("i", $room_id);
$stmt->execute();
$room_result = $stmt->get_result();
$room = $room_result->fetch_assoc();
$stmt->close();

// Fetch existing bookings for this room
$existing_bookings_query = "SELECT checkin_date, checkout_date FROM bookings WHERE room_id = ? AND status IN ('Pending', 'Confirmed')";
$stmt = $conn->prepare($existing_bookings_query);
$stmt->bind_param("i", $room_id);
$stmt->execute();
$existing_bookings_result = $stmt->get_result();
$stmt->close();

$existing_bookings = [];
while ($row = mysqli_fetch_assoc($existing_bookings_result)) {
    $existing_bookings[] = $row;
}

$message = '';
$messageType = '';

if (isset($_POST['book_now'])) {
    $checkin_date = $_POST['checkin_date'];
    $checkout_date = $_POST['checkout_date'];
    $meal_type = $_POST['meal_type'];
    $special_requests = $_POST['special_requests'];

    // 1. Ensure the check-in date is not in the past
    if (strtotime($checkin_date) < strtotime(date("Y-m-d"))) {
        $message = "Check-in date cannot be in the past.";
        $messageType = "error";
    }
    // 2. Ensure the check-out date is after the check-in date
    elseif (strtotime($checkout_date) <= strtotime($checkin_date)) {
        $message = "Check-out date must be after the check-in date.";
        $messageType = "error";
    } else {
        // 3. Check for booking conflicts
        $conflict_query = "SELECT * FROM bookings WHERE room_id = ? AND status IN ('Pending', 'Confirmed') AND ((checkin_date BETWEEN ? AND ?) OR (checkout_date BETWEEN ? AND ?))";
        $stmt = $conn->prepare($conflict_query);
        $stmt->bind_param("issss", $room_id, $checkin_date, $checkout_date, $checkin_date, $checkout_date);
        $stmt->execute();
        $conflict_result = $stmt->get_result();
        if ($conflict_result->num_rows > 0) {
            $message = "This room is not available for the selected dates.";
            $messageType = "error";
        } else {
            // 4. Insert booking details into the database
            $stmt = $conn->prepare("INSERT INTO bookings (user_id, room_id, checkin_date, checkout_date, meal_type, special_requests, status, created_at) VALUES (?, ?, ?, ?, ?, ?, 'Pending', NOW())");
            $stmt->bind_param("iissss", $user_id, $room_id, $checkin_date, $checkout_date, $meal_type, $special_requests);

            if ($stmt->execute()) {
                $message = "Booking successful! Your booking is now pending confirmation.";
                $messageType = "success";
                header("Location: mybookings.php?msg=booking_success");
                exit;
            } else {
                $message = "Error booking room: " . $stmt->error;
                $messageType = "error";
            }
            $stmt->close();
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Book <?php echo $room['type']; ?></title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css">
    <!-- Font Awesome for icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <!-- Custom CSS -->
    <link rel="stylesheet" href="styles.css">
    <style>
    /* Body background with image1 at 30% opacity */
    body {
        background: url('admin/<?php echo $room['image1']; ?>') no-repeat center center fixed;
        background-size: cover;
        position: relative;
        margin: 0;
        padding: 0;
    }

    body::before {
        content: "";
        position: fixed;
        top: 0;
        left: 0;
        width: 100vw;
        height: 100vh;
        background-color: rgba(255, 255, 255, 0.7);
        z-index: -1;
    }

    .content-container {
        position: relative;
        z-index: 1;
        padding: 20px;
        border-radius: 10px;
        background-color: rgba(255, 255, 255, 0.85);
    }

    /* Styling for the image slider */
    .carousel-inner img {
        border-radius: 10px 10px 0 0;
        height: 350px;
        object-fit: cover;
    }

    .navbar {
        z-index: 2;
        background-color: #343a40 !important;
    }

    .navbar .nav-link {
        color: white;
    }

    footer {
        background-color: #343a40;
        padding: 5px;
        padding-top: 20px;
        color: white;
    }

    h2 {
        font-size: 2rem;
        margin-bottom: 15px;
    }

    h3.text-primary {
        font-size: 1.5rem;
        margin-bottom: 15px;
    }

    .room-amenities i {
        color: #007bff;
        margin-right: 8px;
    }
    </style>
</head>

<body>

    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container-fluid">
            <a class="navbar-brand" href="user_home.php">Tulip Garden</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav"
                aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="user_home.php">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="mybookings.php">My Bookings</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="user_rooms.php">Rooms</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="user_payments.php">Payments</a>
                    </li>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="profileDropdown" role="button"
                            data-bs-toggle="dropdown" aria-expanded="false">
                            <i class="fas fa-user"></i>
                        </a>
                        <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="profileDropdown">
                            <li><a class="dropdown-item" href="profile.php"><i class="fas fa-user-edit"></i> Edit
                                    Profile</a></li>
                            <li><a class="dropdown-item" href="logout.php"><i class="fas fa-sign-out-alt"></i>
                                    Logout</a></li>
                        </ul>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <!-- Booking Page -->
    <div class="container mt-5 content-container">

        <!-- Show any error or success messages -->
        <?php if ($message != '') { ?>
        <div class="alert alert-<?php echo $messageType === 'error' ? 'danger' : 'success'; ?>" role="alert">
            <?php echo $message; ?>
        </div>
        <?php } ?>

        <div class="row">
            <!-- Left Side: Availability -->
            <div class="col-md-6">
                <h3>Room Availability</h3>
                <?php if (!empty($existing_bookings)) { ?>
                <ul class="list-group">
                    <?php foreach ($existing_bookings as $booking) { ?>
                    <li class="list-group-item">
                        <strong>Booked:</strong>
                        <?php echo date("M jS, Y", strtotime($booking['checkin_date'])); ?> -
                        <?php echo date("M jS, Y", strtotime($booking['checkout_date'])); ?>
                    </li>
                    <?php } ?>
                </ul>
                <?php } else { ?>
                <p>This room is available for all dates.</p>
                <?php } ?>

                <!-- Image Slider for Room -->
                <div id="roomGallery" class="carousel slide mt-4" data-bs-ride="carousel">
                    <div class="carousel-inner">
                        <?php if ($room['image1']) { ?>
                        <div class="carousel-item active">
                            <img src="admin/<?php echo $room['image1']; ?>" class="d-block w-100" alt="Room Image 1">
                        </div>
                        <?php } ?>
                        <?php if ($room['image2']) { ?>
                        <div class="carousel-item">
                            <img src="admin/<?php echo $room['image2']; ?>" class="d-block w-100" alt="Room Image 2">
                        </div>
                        <?php } ?>
                        <?php if ($room['image3']) { ?>
                        <div class="carousel-item">
                            <img src="admin/<?php echo $room['image3']; ?>" class="d-block w-100" alt="Room Image 3">
                        </div>
                        <?php } ?>
                    </div>
                    <button class="carousel-control-prev" type="button" data-bs-target="#roomGallery"
                        data-bs-slide="prev">
                        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                        <span class="visually-hidden">Previous</span>
                    </button>
                    <button class="carousel-control-next" type="button" data-bs-target="#roomGallery"
                        data-bs-slide="next">
                        <span class="carousel-control-next-icon" aria-hidden="true"></span>
                        <span class="visually-hidden">Next</span>
                    </button>
                </div>
            </div>

            <!-- Right Side: Booking Form -->
            <div class="col-md-6">
                <h3>Book <?php echo $room['type']; ?></h3>
                <p><i class="fas fa-map-marker-alt"></i> Tulip Garden, Alexanderstrasse 15, 12634, Berlin, Germany</p>
                <p class="text-primary">$<?php echo number_format($room['price_per_night'], 2); ?> / night</p>

                <form method="POST">
                    <div class="mb-3">
                        <label for="checkin_date" class="form-label">Check-in Date</label>
                        <input type="date" class="form-control" id="checkin_date" name="checkin_date" required>
                    </div>
                    <div class="mb-3">
                        <label for="checkout_date" class="form-label">Check-out Date</label>
                        <input type="date" class="form-control" id="checkout_date" name="checkout_date" required>
                    </div>
                    <div class="mb-3">
                        <label for="meal_type" class="form-label">Meal Type</label>
                        <select class="form-control" id="meal_type" name="meal_type">
                            <option value="None">None</option>
                            <option value="Vegetarian">Vegetarian</option>
                            <option value="Vegan">Vegan</option>
                            <option value="Halal">Halal</option>
                            <option value="Kosher">Kosher</option>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label for="special_requests" class="form-label">Special Requests</label>
                        <textarea class="form-control" id="special_requests" name="special_requests"
                            rows="3"></textarea>
                    </div>
                    <button type="submit" name="book_now" class="btn btn-primary"><i class="fas fa-calendar-check"></i>
                        Book Now</button>
                </form>
            </div>
        </div>
    </div>

    <!-- Footer -->
    <footer class="text-center mt-5">
        <p>&copy; <?php echo date("Y"); ?> Tulip Garden. All Rights Reserved.</p>
    </footer>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"></script>

</body>

</html>