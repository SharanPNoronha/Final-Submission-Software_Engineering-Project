<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tulip Garden | Room Booking - Luxury Awaits</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="styles.css">
    <style>
    /* General Styles */
    body {
        font-family: 'Poppins', sans-serif;
        background-color: #f3f4f6;
    }

    /* Navbar Styles */
    .navbar-custom {
        background-color: #2c3e50;
        padding: 10px 20px;
        box-shadow: 0px 4px 12px rgba(0, 0, 0, 0.1);
    }

    .navbar-custom .navbar-brand {
        font-weight: bold;
        color: #ecf0f1;
    }

    .navbar-custom .nav-link {
        color: #ecf0f1;
    }

    .navbar-custom .nav-link:hover {
        color: #f39c12;
    }

    /* Hero Section */
    .hero-section {
        background-image: url('assets/images/background.jpg');
        background-size: cover;
        background-position: center;
        height: 100vh;
        color: #fff;
        display: flex;
        flex-direction: column;
        justify-content: center;
        align-items: center;
        text-align: center;
        position: relative;
    }

    .hero-section::before {
        content: '';
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background-color: rgba(0, 0, 0, 0.6);
        z-index: 1;
    }

    .hero-section .content {
        position: relative;
        z-index: 2;
    }

    .hero-section h1 {
        font-size: 4rem;
        font-weight: bold;
        margin-bottom: 20px;
        text-shadow: 2px 2px 10px rgba(0, 0, 0, 0.7);
    }

    .hero-section p {
        font-size: 1.5rem;
        margin-bottom: 40px;
        text-shadow: 1px 1px 10px rgba(0, 0, 0, 0.7);
    }

    .hero-section .btn-primary {
        padding: 15px 30px;
        font-size: 1.2rem;
        background-color: #f39c12;
        border: none;
        border-radius: 30px;
        box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.2);
        transition: background-color 0.3s ease;
    }

    .hero-section .btn-primary:hover {
        background-color: #e67e22;
    }

    /* Features Section */
    .features-section {
        padding: 60px 0;
        background-color: #ecf0f1;
        text-align: center;
    }

    .features-section h2 {
        font-size: 2.5rem;
        margin-bottom: 40px;
        color: #2c3e50;
    }

    .feature {
        margin-bottom: 40px;
    }

    .feature i {
        font-size: 4rem;
        color: #f39c12;
        margin-bottom: 20px;
    }

    .feature h4 {
        font-size: 1.5rem;
        margin-bottom: 15px;
        color: #2c3e50;
    }

    .feature p {
        font-size: 1.1rem;
        color: #7f8c8d;
    }

    /* Footer Styles */
    footer {
        background-color: #2c3e50;
        color: #ecf0f1;
        padding: 20px 0;
        text-align: center;
    }

    footer p {
        margin: 0;
    }
    </style>
</head>

<body>

    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-custom fixed-top">
        <div class="container-fluid">
            <a class="navbar-brand" href="#">Tulip Garden</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav"
                aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="signup.php">Sign Up</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="login.php">Login</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <!-- Hero Section -->
    <div class="hero-section">
        <div class="content">
            <h1>Welcome to Room Booking</h1>
            <p>Experience the ultimate luxury and comfort with our premium room booking service.</p>
            <a href="signup.php" class="btn btn-primary">Get Started</a>
        </div>
    </div>

    <!-- Features Section -->
    <div class="features-section">
        <div class="container">
            <h2>Why Choose Us?</h2>
            <div class="row">
                <div class="col-md-4 feature">
                    <i class="fas fa-concierge-bell"></i>
                    <h4>24/7 Concierge</h4>
                    <p>Our dedicated concierge team is available around the clock to cater to your every need.</p>
                </div>
                <div class="col-md-4 feature">
                    <i class="fas fa-bed"></i>
                    <h4>Luxurious Rooms</h4>
                    <p>Enjoy our beautifully designed rooms, each equipped with premium amenities.</p>
                </div>
                <div class="col-md-4 feature">
                    <i class="fas fa-spa"></i>
                    <h4>World-Class Spa</h4>
                    <p>Relax and rejuvenate with our extensive range of spa treatments.</p>
                </div>
            </div>
        </div>
    </div>

    <!-- Footer -->
    <footer>
        <p>&copy; <?php echo date("Y"); ?> Tulip Garden. All Rights Reserved.</p>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://kit.fontawesome.com/a076d05399.js"></script>
</body>

</html>