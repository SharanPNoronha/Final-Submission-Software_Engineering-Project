<?php
session_start();
include 'config.php';

// Check if the user is logged in
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

$user_id = $_SESSION['user_id'];

// Fetch user details
$user_query = "SELECT * FROM users WHERE id = ?";
$stmt = $conn->prepare($user_query);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$user_result = $stmt->get_result();
$user = $user_result->fetch_assoc();
$stmt->close();

// Get the dynamic max and min values from the database
$max_price_query = "SELECT MAX(price_per_night) as max_price, MIN(price_per_night) as min_price, MAX(max_occupancy) as max_occupancy FROM rooms";
$price_result = mysqli_query($conn, $max_price_query);
$price_row = mysqli_fetch_assoc($price_result);
$max_price = $price_row['max_price'];
$min_price = $price_row['min_price'];
$max_occupancy = $price_row['max_occupancy'];

// Default filter values
$search_query = "";
$price_range = $max_price;
$room_type = "";
$occupancy = $max_occupancy;

$query_parts = [];

// Search logic
if (isset($_GET['search']) && $_GET['search'] !== "") {
    $search_query = $_GET['search'];
    $query_parts[] = "(type LIKE '%" . $search_query . "%' OR description LIKE '%" . $search_query . "%')";
}

// Price range filter using min and max price
if (isset($_GET['minPrice']) && $_GET['minPrice'] !== "" && isset($_GET['maxPrice']) && $_GET['maxPrice'] !== "") {
    $min_price_input = $_GET['minPrice'];
    $max_price_input = $_GET['maxPrice'];
    $query_parts[] = "price_per_night BETWEEN " . $min_price_input . " AND " . $max_price_input;
}


// Room type filter using LIKE for partial matches
if (isset($_GET['roomType']) && $_GET['roomType'] !== "") {
    $room_type = $_GET['roomType'];
    $query_parts[] = "type LIKE '%" . $room_type . "%'";
}

// Max occupancy filter
if (isset($_GET['maxOccupancy']) && $_GET['maxOccupancy'] !== "") {
    $occupancy = $_GET['maxOccupancy'];
    $query_parts[] = "max_occupancy <= " . $occupancy;
}

// Build the query with filters
$rooms_query = "SELECT * FROM rooms";
if (count($query_parts) > 0) {
    $rooms_query .= " WHERE " . implode(" AND ", $query_parts);
}
$rooms_query .= " ORDER BY created_at DESC";
$rooms_result = mysqli_query($conn, $rooms_query);

?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Home - Tulip Garden</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css">
    <!-- Font Awesome for icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <!-- Custom CSS -->
    <link rel="stylesheet" href="styles.css">
    <style>
    /* General styling */
    body {
        background-color: #f7f7f7;
        font-family: 'Poppins', sans-serif;
    }

    .navbar-brand {
        font-weight: bold;
    }

    .jumbotron {
        position: relative;
        background-image: url("assets/images/background-img.png");
        background-size: cover;
        background-repeat: no-repeat;
        background-position: center;
        color: black;
        border-radius: 10px;
        padding: 50px;
        text-align: center;
        overflow: hidden;
        z-index: 1;
    }

    .jumbotron::before {
        content: "";
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background-color: rgba(255, 255, 255, 0.6);
        z-index: -1;
        border-radius: 10px;
    }

    .jumbotron h1,
    .jumbotron p {
        text-shadow: 2px 2px 4px rgba(255, 255, 255, 0.7);
    }

    .search-bar {
        margin: 20px 0;
    }

    .card {
        border: none;
        border-radius: 15px;
        transition: transform 0.2s ease;
    }

    .card img {
        border-top-left-radius: 15px;
        border-top-right-radius: 15px;
        height: 200px;
        object-fit: cover;
    }

    .card-body {
        background-color: #ffffff;
        border-bottom-left-radius: 15px;
        border-bottom-right-radius: 15px;
        box-shadow: 0 8px 15px rgba(0, 0, 0, 0.1);
    }

    .card-title {
        font-weight: bold;
    }

    .card:hover {
        transform: translateY(-10px);
        box-shadow: 0 15px 20px rgba(0, 0, 0, 0.2);
    }

    .filter-btn {
        background-color: #4e54c8;
        color: white;
        margin-left: 10px;
        border-radius: 5px;
    }

    .filter-btn:hover {
        background-color: #8f94fb;
    }

    footer {
        background-color: #343a40;
        color: white;
    }
    </style>
</head>

<body>

    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container-fluid">
            <a class="navbar-brand" href="user_home.php">Tulip Garden</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav"
                aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="user_home.php">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="mybookings.php">My Bookings</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="user_rooms.php">Rooms</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="user_payments.php">Payments</a>
                    </li>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="profileDropdown" role="button"
                            data-bs-toggle="dropdown" aria-expanded="false">
                            <i class="fas fa-user"></i>
                        </a>
                        <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="profileDropdown">
                            <li><a class="dropdown-item" href="profile.php"><i class="fas fa-user-edit"></i> Edit
                                    Profile</a></li>
                            <li><a class="dropdown-item" href="logout.php"><i class="fas fa-sign-out-alt"></i>
                                    Logout</a></li>
                        </ul>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <!-- Hero Section -->
    <div class="container mt-5">
        <div class="jumbotron text-center p-5">
            <h1>Welcome, <?php echo $user['name']; ?>!</h1>
            <p>Enjoy your stay at our hotel. Book a room and explore our services!</p>
        </div>
    </div>

    <!-- Search Bar and Filters -->
    <div class="container">
        <div class="search-bar">
            <form class="d-flex" method="GET" action="">
                <input class="form-control me-2" type="search" name="search" placeholder="Search for rooms..."
                    aria-label="Search" value="<?php echo htmlspecialchars($search_query); ?>">
                <button class="btn btn-primary" type="submit">Search</button>
                <button class="btn filter-btn" type="button" data-bs-toggle="collapse" data-bs-target="#filterOptions"
                    aria-expanded="false" aria-controls="filterOptions"><i class="fas fa-filter"></i> Filter</button>
            </form>
        </div>
    </div>

    <!-- Filter Options -->
    <div class="container">
        <div class="collapse" id="filterOptions">
            <div class="card card-body mb-4">
                <form class="row g-3" method="GET" action="">
                    <input type="hidden" name="search" value="<?php echo htmlspecialchars($search_query); ?>">
                    <div class="col-md-4">
                        <label for="minPrice" class="form-label">Min Price</label>
                        <input type="number" class="form-control" id="minPrice" name="minPrice"
                            min="<?php echo $min_price; ?>" max="<?php echo $max_price; ?>"
                            value="<?php echo isset($_GET['minPrice']) ? $_GET['minPrice'] : $min_price; ?>">
                    </div>
                    <div class="col-md-4">
                        <label for="maxPrice" class="form-label">Max Price</label>
                        <input type="number" class="form-control" id="maxPrice" name="maxPrice"
                            min="<?php echo $min_price; ?>" max="<?php echo $max_price; ?>"
                            value="<?php echo isset($_GET['maxPrice']) ? $_GET['maxPrice'] : $max_price; ?>">
                    </div>

                    <div class="col-md-4">
                        <label for="roomType" class="form-label">Room Type</label>
                        <select class="form-select" id="roomType" name="roomType">
                            <option value="">Choose...</option>
                            <option value="Deluxe" <?php echo ($room_type == "Deluxe") ? "selected" : ""; ?>>Deluxe
                            </option>
                            <option value="Standard" <?php echo ($room_type == "Standard") ? "selected" : ""; ?>>
                                Standard
                            </option>
                            <option value="Suite" <?php echo ($room_type == "Suite") ? "selected" : ""; ?>>Suite
                            </option>
                            <option value="Single" <?php echo ($room_type == "Single") ? "selected" : ""; ?>>Single
                            </option>
                            <option value="Double" <?php echo ($room_type == "Double") ? "selected" : ""; ?>>Double
                            </option>
                        </select>
                    </div>
                    <div class="col-md-4">
                        <label for="maxOccupancy" class="form-label">Max Occupancy</label>
                        <input type="number" class="form-control" id="maxOccupancy" name="maxOccupancy" min="1"
                            max="<?php echo $max_occupancy; ?>" value="<?php echo $occupancy; ?>">
                    </div>
                    <div class="col-12">
                        <button type="submit" class="btn btn-primary">Apply Filters</button>
                        <a href="user_home.php" class="btn btn-secondary">Clear Filters</a>

                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Available Rooms Section -->
    <div class="container mt-5">
        <h2 class="mb-4">Available Rooms</h2>
        <div class="row">
            <?php while ($room = mysqli_fetch_assoc($rooms_result)) { ?>
            <div class="col-md-4 mb-4">
                <div class="card">
                    <img src="admin/<?php echo $room['image1']; ?>" class="card-img-top" alt="Room Image">
                    <div class="card-body">
                        <h5 class="card-title"><?php echo $room['type']; ?></h5>
                        <p class="card-text"><?php echo substr($room['description'], 0, 100); ?>...</p>
                        <p class="card-text"><strong>Price per Night:</strong>
                            $<?php echo number_format($room['price_per_night'], 2); ?></p>
                        <a href="room_details.php?id=<?php echo $room['id']; ?>" class="btn btn-primary"><i
                                class="fas fa-info-circle"></i> View Details</a>
                    </div>
                </div>
            </div>
            <?php } ?>
        </div>
    </div>

    <!-- Footer -->
    <footer class="bg-dark text-white text-center p-3 mt-5">
        <p>&copy; <?php echo date("Y"); ?> Tulip Garden. All Rights Reserved.</p>
    </footer>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"></script>

</body>

</html>