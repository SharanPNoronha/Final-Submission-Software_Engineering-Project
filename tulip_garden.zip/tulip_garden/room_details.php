<?php
session_start();
include 'config.php';

// Check if the user is logged in
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

$room_id = $_GET['id'];

// Fetch room details
$room_query = "SELECT * FROM rooms WHERE id = ?";
$stmt = $conn->prepare($room_query);
$stmt->bind_param("i", $room_id);
$stmt->execute();
$room_result = $stmt->get_result();
$room = $room_result->fetch_assoc();
$stmt->close();

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $room['type']; ?> Details - Tulip Garden</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css">
    <!-- Font Awesome for icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <!-- Custom CSS -->
    <link rel="stylesheet" href="styles.css">
    <style>
    body {
        background: url('admin/<?php echo $room['image1']; ?>') no-repeat center center fixed;
        background-size: cover;
        position: relative;
        margin: 0;
        padding: 0;
    }

    body::before {
        content: "";
        position: fixed;
        top: 0;
        left: 0;
        width: 100vw;
        height: 100vh;
        background-color: rgba(255, 255, 255, 0.7);
        z-index: -1;
        pointer-events: none;
    }

    .content-container {
        position: relative;
        z-index: 1;
        padding: 20px;
        border-radius: 10px;
        background-color: rgba(255, 255, 255, 0.85);
    }

    .navbar {
        z-index: 2;
        background-color: #343a40 !important;
    }

    .navbar .nav-link {
        color: white;
    }


    .card {
        border-radius: 10px;
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    }

    .carousel-inner img {
        border-radius: 10px 10px 0 0;
        height: 350px;
        object-fit: cover;
    }

    h2 {
        font-size: 2rem;
        margin-bottom: 15px;
    }

    h3.text-primary {
        font-size: 1.5rem;
        margin-bottom: 15px;
    }

    .d-flex {
        margin-bottom: 10px;
    }

    hr {
        margin: 20px 0;
        border: 1px solid #ddd;
    }

    /* Room Amenities */
    .room-amenities span,
    .additional-services span {
        font-size: 1.2rem;
        color: #6c757d;
        margin-bottom: 10px;
        display: inline-block;
    }

    .room-amenities i,
    .additional-services i {
        color: #007bff;
        margin-right: 8px;
    }

    .additional-services {
        margin-bottom: 20px;
    }

    footer {
        background-color: #343a40;
        padding: 5px;
        padding-top: 20px;
        color: white;

    }
    </style>
</head>

<body>

    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container-fluid">
            <a class="navbar-brand" href="user_home.php">Tulip Garden</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav"
                aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="user_home.php">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="mybookings.php">My Bookings</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="user_rooms.php">Rooms</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="user_payments.php">Payments</a>
                    </li>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="profileDropdown" role="button"
                            data-bs-toggle="dropdown" aria-expanded="false">
                            <i class="fas fa-user"></i>
                        </a>
                        <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="profileDropdown">
                            <li><a class="dropdown-item" href="profile.php"><i class="fas fa-user-edit"></i> Edit
                                    Profile</a></li>
                            <li><a class="dropdown-item" href="logout.php"><i class="fas fa-sign-out-alt"></i>
                                    Logout</a></li>
                        </ul>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <!-- Room Details Section -->
    <div class="container mt-5 content-container">
        <div class="row">
            <!-- Room Image Gallery -->
            <div class="col-md-7">
                <div class="card">
                    <div id="roomGallery" class="carousel slide" data-bs-ride="carousel">
                        <div class="carousel-inner">
                            <?php if ($room['image1']) { ?>
                            <div class="carousel-item active">
                                <img src="admin/<?php echo $room['image1']; ?>" class="d-block w-100"
                                    alt="Room Image 1">
                            </div>
                            <?php } ?>
                            <?php if ($room['image2']) { ?>
                            <div class="carousel-item">
                                <img src="admin/<?php echo $room['image2']; ?>" class="d-block w-100"
                                    alt="Room Image 2">
                            </div>
                            <?php } ?>
                            <?php if ($room['image3']) { ?>
                            <div class="carousel-item">
                                <img src="admin/<?php echo $room['image3']; ?>" class="d-block w-100"
                                    alt="Room Image 3">
                            </div>
                            <?php } ?>
                        </div>
                        <button class="carousel-control-prev" type="button" data-bs-target="#roomGallery"
                            data-bs-slide="prev">
                            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                            <span class="visually-hidden">Previous</span>
                        </button>
                        <button class="carousel-control-next" type="button" data-bs-target="#roomGallery"
                            data-bs-slide="next">
                            <span class="carousel-control-next-icon" aria-hidden="true"></span>
                            <span class="visually-hidden">Next</span>
                        </button>
                    </div>
                </div>
            </div>

            <!-- Room Information -->
            <div class="col-md-5">
                <h2><?php echo $room['type']; ?></h2>
                <p><i class="fas fa-map-marker-alt"></i> Tulip Garden, Alexanderstrasse 15, 12634, Berlin, Germany</p>
                <h3 class="text-primary">$<?php echo number_format($room['price_per_night'], 2); ?> / night</h3>
                <div class="d-flex justify-content-between align-items-center">
                    <span><i class="fas fa-users"></i> Max Occupancy: <?php echo $room['max_occupancy']; ?></span>
                </div>
                <hr>
                <h4>Room Amenities</h4>
                <div class="room-amenities">
                    <span class="me-4"><i class="fas fa-spa"></i> Spa</span>
                    <span class="me-4"><i class="fas fa-swimming-pool"></i> Swimming Pool</span>
                    <span class="me-4"><i class="fas fa-utensils"></i> Meals Included</span>
                    <span class="me-4"><i class="fas fa-wifi"></i> Free Wi-Fi</span>
                    <span class="me-4"><i class="fas fa-car"></i> Free Parking</span>
                    <span class="me-4"><i class="fas fa-dumbbell"></i> Gym</span>
                </div>
                <hr>
                <h4>Additional Services</h4>
                <div class="additional-services">
                    <span class="me-4"><i class="fas fa-concierge-bell"></i> 24/7 Room Service</span>
                    <span class="me-4"><i class="fas fa-shuttle-van"></i> Airport Shuttle</span>
                    <span class="me-4"><i class="fas fa-child"></i> Babysitting Service</span>
                    <span class="me-4"><i class="fas fa-glass-cheers"></i> Bar/Lounge Access</span>
                    <span class="me-4"><i class="fas fa-laptop-house"></i> Business Center</span>
                </div>
                <hr>
                <h4>Room Details</h4>
                <p><?php echo $room['description']; ?></p>
                <a href="book_room.php?id=<?php echo $room['id']; ?>" class="btn btn-primary"><i
                        class="fas fa-calendar-check"></i> Book Now</a>
            </div>
        </div>
    </div>

    <!-- Footer -->
    <footer class="text-center mt-5">
        <p>&copy; <?php echo date("Y"); ?> Tulip Garden. All Rights Reserved.</p>
    </footer>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"></script>

</body>

</html>